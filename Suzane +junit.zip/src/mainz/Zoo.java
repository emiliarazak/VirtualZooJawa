/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainz;
import Animal.Squamata.Python.Python;
import Animal.*;
import Indices.*;
/**
 *
 * @author User
 */
public class Zoo {
    /**
     * @param args the command line arguments
     */
  public static void main(String[] args) {
    Python P = new Python(60, 3, 3);
    P.Interact();
    System.out.println(P.GetBerat());
    P.GetKoordinat().PrintKoordinat();
  }
}