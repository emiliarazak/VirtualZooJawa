/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animal.Primates.Monkey;

import Animal.Primates.Primates;

/**
 *
 * @author User
 */
public class Monkey extends Primates {
  /** @brief Constructor dari Monkey
    * Menghidupkan hewan Monkey
    *
    * @param x integer adalah letak absis Monkey yang dihidupkan
    * @param y integer adalah letak ordinat Monkey yang dihidupkan
    * @param bb integer adalah berat badan Monkey yang dihidupkan
    */
  public Monkey(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
  }
  
  @Override
  /** @brief prosedur Interact dari objek Monkey
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Monkey ke layar
    */
  public void Interact() {
    System.out.println("U u a a");
  }
}