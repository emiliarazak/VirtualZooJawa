/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animal.Primates;

import Animal.Animal;

/**
 *
 * @author User
 */
public abstract class Primates extends Animal {
  /** @brief Constructor dari Primates
    * Menghidupkan hewan Ordo Primates
    *
    * @param x integer adalah letak absis Primates yang dihidupkan
    * @param y integer adalah letak ordinat Primates yang dihidupkan
    * @param kejinakan boolean menyatakan jinak tidaknya hewan
    */    
  public Primates(boolean kejinakan, int x, int y) {
    super(1, true, false, false,kejinakan,x,y);
  }
}
