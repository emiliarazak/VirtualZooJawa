package animal;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AnimalTest {
	private Animal a = new Animal('K', 2000, 3, 4, 2, false, true, false, false);
	private Animal b = new Animal();
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}
	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}
	@Test
	public void testAnimalCharIntIntIntIntBooleanBooleanBooleanBoolean() {
		assertEquals("Constructor Animal parameter 1 Error!", 'K', a.render());
		assertEquals("Constructor Animal parameter 2 Error!", 2000, a.getBerat());
		assertEquals("Constructor Animal parameter 3 Error!", 3, a.getKoordinat().getAbsis());
		assertEquals("Constructor Animal parameter 4 Error!", 4, a.getKoordinat().getOrdinat());
		assertEquals("Constructor Animal parameter 5 Error!", 2, a.getMakanan());
		assertEquals("Constructor Animal parameter 6 Error!", false, a.isLandAnimal());
		assertEquals("Constructor Animal parameter 7 Error!", true, a.isWaterAnimal());
		assertEquals("Constructor Animal parameter 8 Error!", false, a.isAirAnimal());
		assertEquals("Constructor Animal parameter 9 Error!", false, a.isJinak());
	}
	@Test
	public void testInteract() {
		a.interact();
		assertEquals("Interact() Error!", "*Big grins* heyyo\n", outContent.toString());
	}
	@Test
	public void testGetBerat() {
		assertEquals("GetBerat() Error!", 2000, a.getBerat());
	}
	@Test
	public void testSetBerat() {
		a.setBerat(1500);
		assertEquals("SetBerat() Error!", 1500, a.getBerat());
		a.setBerat(2000);
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat() Error!", 3, a.getKoordinat().getAbsis());
		assertEquals("GetKoordinat() Error!", 4, a.getKoordinat().getOrdinat());
	}
	@Test
	public void testSetKoordinat() {
		a.setKoordinat(5,6);
		assertEquals("SetKoordinat() Error!", 5, a.getKoordinat().getAbsis());
		assertEquals("SetKoordinat() Error!", 6, a.getKoordinat().getOrdinat());
		a.setKoordinat(3,4);
	}
	@Test
	public void testIsLandAnimal() {
		assertEquals("IsLandAnimal() Error!", false, a.isLandAnimal());
	}

	@Test
	public void testIsWaterAnimal() {
		assertEquals("IsWaterAnimal() Error!", true, a.isWaterAnimal());
	}

	@Test
	public void testIsAirAnimal() {
		assertEquals("IsAirAnimal() Error!", false, a.isAirAnimal());
	}

	@Test
	public void testIsJinak() {
		assertEquals("IsJinak() Error!", false, a.isJinak());
	}

	@Test
	public void testGetMakanan() {
		assertEquals("GetMakanan() Error!", 2, a.getMakanan());
	}

	@Test
	public void testCopyAnimal() {
		b.copyAnimal(a);
		assertEquals("Copy Animal parameter 1 Error!", 'K', b.render());
		assertEquals("Copy Animal parameter 2 Error!", 2000, b.getBerat());
		assertEquals("Copy Animal parameter 3 Error!", 3, b.getKoordinat().getAbsis());
		assertEquals("Copy Animal parameter 4 Error!", 4, b.getKoordinat().getOrdinat());
		assertEquals("Copy Animal parameter 5 Error!", 2, b.getMakanan());
		assertEquals("Copy Animal parameter 6 Error!", false, b.isLandAnimal());
		assertEquals("Copy Animal parameter 7 Error!", true, b.isWaterAnimal());
		assertEquals("Copy Animal parameter 8 Error!", false, b.isAirAnimal());
		assertEquals("Copy Animal parameter 9 Error!", false, b.isJinak());
	}

	@Test
	public void testRender() {
		assertEquals("render() Error!", 'K', a.render());
	}
}
