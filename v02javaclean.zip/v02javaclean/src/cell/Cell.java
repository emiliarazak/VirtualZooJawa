package cell;

import indices.Indices;
/**Kelas Cell tanpa inheritance.
 * 
 * @author alivia
 *
 */

public class Cell {
  /** Atribut koordinat yang adalah Indices letak Cell.
    */
  Indices koordinat;
  /** Atribut code yang adalah code dari Cell.
    */
  char code;
  /**Constructor tanpa parameter dari Cell.
    *Menghidupkan Cell.
    */
  
  public Cell() {}
  /** Constructor dari Cell.
    * Menghidupkan Cell
    *
    * @param ind Indices adalah alamat dimana Cell dihidupkan.
    */
  
  public Cell(Indices ind, char c) {
    code = c;
    koordinat = ind;
  }
  /**  Mengembalikan nilai Indices dimana Cell berada.
    */
  
  public Indices getKoordinat() {
    return koordinat;
  }
  /** Mengembalikan nilai boolean apakah Cell adalah habitat.
    */
  
  public boolean isHabitat() {
    return ((code == 'l') || (code == 'w') || (code == 'a'));
  }
  /** Mengembalikan nilai booleanean apakah Cell adalah fasilitas.
    */
  
  public boolean isFacility() {
    return ((code == 'P') || (code == 'R') || (code == 'S'));
  }
  /**Mengembalikan nilai char Code yang adalah atribut Cell.
    */
  
  public char getCode() {
    return code;
  }
  /**Mengembalikan nilai booleanean apakah Cell adalah road.
    */
  
  public boolean isRoad() {
    return ((code == '-') || (code == '+') || (code == '='));
  }
  /**Mengembalikan nilai booleanean apakah Cell adalah Park.
    */
  
  public boolean isPark() {
    return (code == 'P');
  }
  /**Mengembalikan nilai booleanean apakah Cell adalah restaurant.
    */
  
  public boolean isRestaurant() {
    return (code == 'R');
  }
  /**Mengembalikan nilai booleanean apakah Cell adalah land.
    */
  
  public boolean isLand() {
    return (code == 'l');
  }
  /**Mengembalikan nilai booleanean apakah Cell adalah water.
    */
  
  public boolean isWater() {
    return (code == 'w');
  }
  /**Mengembalikan nilai booleanean apakah Cell adalah air.
    */
  
  public boolean isAir() {
    return (code == 'a');
  }
  /**Mengembalikan nilai kode char dari objek Cell.
    *char ini nantinya yang siap dicetak ke layar.
    */
  
  public char render() {
    return code;
  }  
}
