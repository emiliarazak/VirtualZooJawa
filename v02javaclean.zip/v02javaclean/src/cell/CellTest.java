package cell;

import static org.junit.Assert.*;

import org.junit.Test;

import indices.Indices;

public class CellTest {
	private Indices ind = new Indices(5,6);
	private Cell c = new Cell (ind, 'a');
	@Test
	public void testCellIndicesChar() {
		assertEquals("Constructor Cell Parameter 1 Error!", 5, c.getKoordinat().getAbsis());
		assertEquals("Constructor Cell Parameter 1 Error!", 6, c.getKoordinat().getOrdinat());
		assertEquals("Constructor Cell Parameter 2 Error!", 'a', c.getCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat() Error!", 5, c.getKoordinat().getAbsis());
		assertEquals("GetKoordinat() Error!", 6, c.getKoordinat().getOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("IsHabitat() Error!", true, c.isHabitat());
	}

	@Test
	public void testIsFacility() {
		assertEquals("IsFacility() Error!", false, c.isFacility());
	}

	@Test
	public void testGetCode() {
		assertEquals("GetCode() Error!", 'a', c.getCode());
	}

	@Test
	public void testIsRoad() {
		assertEquals("IsRoad() Error!", false, c.isRoad());
	}

	@Test
	public void testIsPark() {
		assertEquals("IsPark() Error!", false, c.isPark());
	}

	@Test
	public void testIsRestaurant() {
		assertEquals("IsRestaurant() Error!", false, c.isRestaurant());
	}

	@Test
	public void testIsLand() {
		assertEquals("IsLand() Error!", false, c.isLand());
	}

	@Test
	public void testIsWater() {
		assertEquals("IsWater() Error!", false, c.isWater());
	}

	@Test
	public void testIsAir() {
		assertEquals("IsAir() Error!", true, c.isAir());
	}

	@Test
	public void testRender() {
		assertEquals("Render() Error!", 'a', c.render());
	}
}