package cage;
import static org.junit.Assert.*;
import animal.Animal;
import org.junit.Test;
import indices.Indices;


public class CageTest {
	@Test
	public void testCageIndicesArrayInt() {
		System.out.println("Constructor");
	}

	@Test
	public void testIsHostOf() {
		int i;
	    System.out.println("isHostOf");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].setAbsis(0); ind[0].setOrdinat(0);
	    ind[1].setAbsis(0); ind[1].setOrdinat(1);
	    ind[2].setAbsis(1); ind[2].setOrdinat(0);
	    ind[3].setAbsis(1); ind[3].setOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    Indices test;
	    test = new Indices(4,5);
	    
	    assertEquals("Salah isHostOf", false, instance.isHostOf(test));
	}

	@Test
	public void testSpacious() {
		int i;
	    System.out.println("spacious");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].setAbsis(0); ind[0].setOrdinat(0);
	    ind[1].setAbsis(0); ind[1].setOrdinat(1);
	    ind[2].setAbsis(1); ind[2].setOrdinat(0);
	    ind[3].setAbsis(1); ind[3].setOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    assertEquals("Salah spacious", true, instance.spacious());
	}

	@Test
	public void testAddAnimal() {
		int i;
	    System.out.println("addAnimal");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].setAbsis(0); ind[0].setOrdinat(0);
	    ind[1].setAbsis(0); ind[1].setOrdinat(1);
	    ind[2].setAbsis(1); ind[2].setOrdinat(0);
	    ind[3].setAbsis(1); ind[3].setOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    Animal test = new Animal('K', 2000, 0, 0, 2, false, true, false, false);
	    instance.addAnimal(test);
	   // System.out.println(instance.GetAnimals()[0].render());
	    //instance.GetAnimals()[0].Interact();
	    assertEquals("Salah addAnimals", 1, instance.getBanyakHewan());
	}

	@Test
	public void testInter() {
		System.out.println("inter");
	}

	@Test
	public void testGetAnimals() {
		int i;
	    System.out.println("getAnimal");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].setAbsis(0); ind[0].setOrdinat(0);
	    ind[1].setAbsis(0); ind[1].setOrdinat(1);
	    ind[2].setAbsis(1); ind[2].setOrdinat(0);
	    ind[3].setAbsis(1); ind[3].setOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    Animal test = new Animal('K', 2000, 0, 0, 2, false, true, false, false);
	    instance.addAnimal(test);
	    
	    assertEquals("Salah GetAnimal test render", test.render(), instance.getAnimals()[0].render());
	    assertEquals("Salah GetAnimal test berat", test.getBerat(), instance.getAnimals()[0].getBerat());
	     
	}

	@Test
	public void testGetLuas() {
		int i;
	    System.out.println("getLuas");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].setAbsis(0); ind[0].setOrdinat(0);
	    ind[1].setAbsis(0); ind[1].setOrdinat(1);
	    ind[2].setAbsis(1); ind[2].setOrdinat(0);
	    ind[3].setAbsis(1); ind[3].setOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    assertEquals("Salah luas", 4, instance.getLuas());
	}

	@Test
	public void testGetBanyakHewan() {
		int i;
	    System.out.println("getBanyakHewan");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].setAbsis(0); ind[0].setOrdinat(0);
	    ind[1].setAbsis(0); ind[1].setOrdinat(1);
	    ind[2].setAbsis(1); ind[2].setOrdinat(0);
	    ind[3].setAbsis(1); ind[3].setOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    assertEquals("Salah banyak_hewan", 0, instance.getBanyakHewan());
	}

	@Test
	public void testGetWilayah() {
		int i;
	    System.out.println("getWilayah");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].setAbsis(0); ind[0].setOrdinat(0);
	    ind[1].setAbsis(0); ind[1].setOrdinat(1);
	    ind[2].setAbsis(1); ind[2].setOrdinat(0);
	    ind[3].setAbsis(1); ind[3].setOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    assertEquals("Salah wilayah 1 absis", 0, instance.getWilayah()[0].getAbsis());
	    assertEquals("Salah wilayah 1 ordinat", 0, instance.getWilayah()[0].getOrdinat());
	    assertEquals("Salah wilayah 2 absis", 0, instance.getWilayah()[1].getAbsis());
	    assertEquals("Salah wilayah 2 ordinat", 1, instance.getWilayah()[1].getOrdinat());
	    assertEquals("Salah wilayah 3 absis", 1, instance.getWilayah()[2].getAbsis());
	    assertEquals("Salah wilayah 3 ordinat", 0, instance.getWilayah()[2].getOrdinat());
	    assertEquals("Salah wilayah 4 absis", 1, instance.getWilayah()[3].getAbsis());
	    assertEquals("Salah wilayah 4 ordinat", 1, instance.getWilayah()[3].getOrdinat());
	    
	}

	@Test
	public void testCopyCage() {
		 System.out.println("copyCage");
	}
}
