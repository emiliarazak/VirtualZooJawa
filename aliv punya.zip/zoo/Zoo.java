package zoo;

/**
 * @author aliviaprht
 * @version 3.0
 * @since 24-03-2017
 */

import java.util.Random;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import cage.*;
import indices.*;

public class Zoo {
	//Atribut
	
	/**  Atribut map adalah Matriks of Cell
    */
  private Cell map[][];
  /**  Atribut daftar_kandang adalah Array of Cage yang dimiliki kebun binatang
  */
  private Cage daftar_kandang[];
  /**  Atribut lebar adalah lebar dari kebun binatang
    */
  private int lebar;
  /**  Atribut panjang adalah panjang dari kebun binatang
    */
  private int panjang;
  /**  Atribut banyak_kandang adalah jumlah kandang yang ada di kebun binatang
    */
  private int banyak_kandang;
  /**  Atribut ready_to_print adalah Matriks of character kebun binatang yang siap dicetak ke layar (sudah ada hewan)
    */
  private char ready_to_print[][];
  /**  Atribut base_map adalah Matriks of character kebun binatang hasil render habitat (belum ada hewan)
    */
  private char base_map[][];
  /**  ukuran default panjang dan lebar zoo
    */
  private int DEFSIZE=20;
  
  //Method
  /** Constructor dari Zoo
    * Menghidupkan kebun binatang
    * @return nothing
    */
 public Zoo(){
	 int input_lebar = 0;
	 int input_panjang = 0;
	 int input_banyak_kandang = 0;
	 int i,j,k;
	 Indices[][] temp_indices;
	 int[] neff_kandang;
	 
	 FileInputStream fstream = new FileInputStream("map.txt");
	 BufferedReader br = new BufferedReader (new InputStreamReader(fstream));
	 
	 String strLine;
	 strLine = br.readLine();
	 for (i=0; i<strLine.length(); i++) {
		 input_lebar = (input_lebar *10) + ((int) strLine.charAt(i) - 48);
	 }
	 
	 strLine = br.readLine();
	 for (i=0; i<strLine.length(); i++) {
		 input_panjang = (input_panjang *10) + ((int) strLine.charAt(i) - 48);
	 }
	 
	 strLine = br.readLine();
	 for (i=0; i<strLine.length(); i++) {
		 input_banyak_kandang = (input_banyak_kandang *10) + ((int) strLine.charAt(i) - 48);
	 }
	 
	 temp_indices = new Indices[input_banyak_kandang][25];
	 for(i=0; i<input_banyak_kandang; i++) {
		 for (j=0; j<25; j++) {
			 temp_indices[i][j] = new Indices();
		 }
	 }
	 
	 lebar = input_lebar;
	 panjang = input_panjang;
	 map = new Cell[lebar][panjang];
	 banyak_kandang = input_banyak_kandang;
	 neff_kandang = new int[banyak_kandang];
	 for (i=0; i<banyak_kandang; i++) {
		 neff_kandang[i] = 0;
	 }
	 
	 char habitat;
	 int code;
	 Indices ind;
	 ind = new Indices(0,0);
	 for (i=0; i<lebar; i++) {
		 strLine = br.readLine();
		 j = 0;
		 k = 0;
		 while (j < input_panjang *2) {
			 ind.SetAbsis(k);
			 habitat = strLine.charAt(j);
			 if (habitat == 'W') {
	  		     map[i][k] = new WaterHabitat(ind);
			 } 
			 else if (habitat == 'L') {
			     map[i][k] = new LandHabitat(ind);
			 }
			 else if (habitat == 'A') {
			     map[i][k] = new AirHabitat(ind);
			 }
			 else if (habitat == '-') {
			     map[i][k] = new Road(ind, 0);
			 }
			 else if (habitat == '+') {
				 map[i][k] = new Road(ind, 1);
			 }
			 else if (habitat == '=') {
				 map[i][k] = new Road(ind, 2);
			 }
			 else if (habitat == 'P') {
				 map[i][k] = new Park(ind);
			 }
			 else if (habitat == 'R') {
				 map[i][k] = new Restaurant(ind);
			 } 
			 else {

	          }
			 j++; k++;
			 code = ((int) strLine.charAt(j) - 48);
			 if (code != 0) {
				 temp_indices[code-1][neff_kandang[code-1]].CopyIndices(ind);
				 neff_kandang[code-1]++;
			 }
			 j++;
		 }
	 }
	 br.close();
	 
	 daftar_kandang = new Cage[banyak_kandang];
	 for (i=0; i<banyak_kandang; i++) {
		 daftar_kandang[i] = new Cage();
	 }
	 Indices[] temp_indices_input;
	 for (i=0; i < banyak_kandang; i++) {
		 temp_indices_input = new Indices[25];
		 for (j=0; j<25; j++) {
			 temp_indices_input[j] = new Indices();
		 }
		 
		 for (j=0; j< neff_kandang[i]; j++) {
			 temp_indices_input[j].CopyIndices(temp_indices[i][j]);
		 }
		 Cage C;
		 C = new Cage(temp_indices_input,neff_kandang[i]);
		 daftar_kandang[i].CopyCage(C);
	 }
	 
	 base_map = new char[lebar][panjang];
	 ready_to_print = new char[lebar][panjang];
	 for(i=0; i<lebar; i++) {
		 for (j=0; j<panjang; j++) {
			 base_map[i][j] = map[i][j].Render();
			 ready_to_print[i][j] = base_map[i][j];
		 }
	 }
	 
	 //Memasukkan Binatang
	 
	 int absis_hewan;
	 int ordinat_hewan;
	 for (i=0; i< banyak_kandang; i++) {
		 for (j=0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
			 absis_hewan = daftar_kandang[i].GetAnimals()[j].GetKoordinat().GetAbsis();
			 ordinat_hewan = daftar_kandang[i].GetAnimals()[j].GetKoordinat().GetOrdinat();
			 ready_to_print[absis_hewan][ordinat_hewan] = daftar_kandang[i].GetAnimals()[j].Render();
		 }
	 }
 }
 /**  Prosedur Move
   * I.S Semua elemen dalam kebun binatang telah dihidupkan
   * F.S Semua Animals dalam berpindah tempat
   * Menggerakkan hewan yang ada didalam kebun binatang
   * @return nothing
   */
 public void Move(){
	 boolean move;
	 Indices ind;
	 int count, x, y, to, to_x, to_y;
	 Random rand = new Random();
	 ind = new Indices();
	 
	 for (int i = 0; i < banyak_kandang; i++) {
	      for (int j=0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
	        move = false;
	        count = 0;
	        x = (daftar_kandang[i].GetAnimals()[j]).GetKoordinat().GetAbsis();
	        y = (daftar_kandang[i].GetAnimals()[j]).GetKoordinat().GetOrdinat();
	        to = rand.nextInt(4) + 1;
	        while ((!(move)) && (count < 4)){
	          to_x = x; to_y = y;
	          count++;
	          switch (to) {
	            case 1 : {to_x++;}; break;
	            case 2 : {to_y++;}; break;
	            case 3 : {to_x--;}; break; 
	            case 4 : {to_y--;}; break;        
	          }
	          if ((to_y >= 0) && (to_y < lebar) && (to_x >= 0) && (to_x < panjang)) {
		        ind.SetOrdinat(to_y); ind.SetAbsis(to_x);
			    if (((daftar_kandang[i].GetAnimals()[j]).IsLivable(map[to_y][to_x])) && 
			    	(daftar_kandang[i].IsHostOf(ind)) && ((ready_to_print[to_y][to_x] == 'w') || (ready_to_print[to_y][to_x] == 'l') || (ready_to_print[to_y][to_x] == 'a'))){
					  move = true;
					  (daftar_kandang[i].GetAnimals()[j]).SetKoordinat(to_x, to_y);
					  ready_to_print[y][x] = base_map[y][x];
					  ready_to_print[to_y][to_x] = (daftar_kandang[i].GetAnimals()[j]).Render();
				} 
				else {
				      to = (to % 4) + 1;
				}
			  }
			  else {
			    to = (to % 4) + 1;
			  }
	        }        
	      }
	    } 
 }
 /**  Prosedur Print
   * I.S Zoo telah hidup
   * F.S Semua elemen zoo tercetak pada layar
   * Mencetak kebun binatang beserta seluruh elemennya ke layar
   * @return nothing
   */
 public void Print(){
	 for (int i=0; i<lebar; i++) {
		 for (int j=0; j<panjang; j++) {
			 System.out.print(ready_to_print[i][j]);
			 System.out.print(" ");
		 }
		 System.out.println();
	 }
 }
 /**  Prosedur Hitung Makanan
   * I.S Zoo telah hidup
   * F.S Jumlah makanan yang dibutuhkan kebun binatang setiap harinya tercetak di layar
   * Mengkalkulasikan jumlah makanan yang diperlukan hewan-hewan yang hidup di kebun binatang
   * Mencetak hasil kalkulasi jumlah makanan ke layar
   * @return nothing
   */
 public void HitungMakanan(){
	 int sayur_buah_dan_biji2an = 0;
	 int daging = 0;
	 int i,j;
	 for (i=0; i< banyak_kandang; i++) {
		 for (j=0; j< daftar_kandang[i].GetBanyakHewan(); j++) {
			 if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 0) {
				 sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 100);        
			 }
			 else if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 1) {
		          sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 200);
		          daging = daging + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 200);
		     } 
			 else if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 2) {
		          daging = daging + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 100);
		     }
		 }
	 }
	 
	 System.out.println("Butuh daging sebanyak " + daging + "kg.");
	 System.out.println("Butuh sayur,buah, dan biji-bijian sebanyak " + sayur_buah_dan_biji2an + "kg.");
 }
 /**  Mengembalikan bool apakah indeks tertentu bersinggungan dengan sebuah kandang
   *
   * @param ind adalah indeks yang akan diperiksa
   * @param c adalah kandang yang akan diperiksa
   * @return boolean
   */
 public boolean IsInteractable(Indices ind, Cage c){
	 boolean iya = false;
		int i = 0;
		Indices it;
		it = new Indices();
		
		it.SetAbsis(ind.GetAbsis()+1); it.SetOrdinat(ind.GetOrdinat());
		iya = (c.IsHostOf(it));
		if (!iya) {
	      it.SetAbsis(ind.GetAbsis()-1); it.SetOrdinat(ind.GetOrdinat());
		  iya = (c.IsHostOf(it));
		}
		if (!iya) {
		  it.SetAbsis(ind.GetAbsis()); it.SetOrdinat(ind.GetOrdinat()+1);
		  iya = (c.IsHostOf(it));
		}
		if (!iya) {
	      it.SetAbsis(ind.GetAbsis()); it.SetOrdinat(ind.GetOrdinat()-1);
		  iya = (c.IsHostOf(it));
		}
		return iya;
 }
 /** Getter daftar kandang pada zoo
   * @return array of cage
   */
 public Cage[] GetKandang(){
	 return daftar_kandang;
 }
 /** Getter ready_to_print pada zoo
   * @return matriks of char 
   */
 public char[][] GetPrint(){
	 return ready_to_print;
 }
 /** Melakukan tour pada zoo
   * I.S Semua elemen pada zoo terdefinisi
   * F.S Melakukan tour di zoo dan berinteraksi pada tiap animal yang dilewati
   * @return nothing
   */
 public void Tour(){
	 Random rand = new Random();
	 boolean jalan;
     Indices[] ent;
	 Indices[] ex;
	 int count_entrance,count_exit;
	 int i,j;
	 int idx_entrance=0;
	 int temp_int = 0;
	 char[][] map;
	 count_entrance = 0;
	 count_exit = 0;
	 map = new char [lebar][panjang];
	    
	    //mindahin map di zoo ke temp map
	    for (i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	          map[i][j] = ready_to_print[i][j];
	      }
	    }
	    
	    //mencari entrance
	    for (i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if (map[i][j] == '+') {
	          count_entrance++;
	        }
	      }
	    }
	    
	    //memasukkan koordinat entrance ke array of Indices
	    ent = new Indices [count_entrance];
	    for (i=0; i<count_entrance; i++) {
	    	ent[i] = new Indices();
	    }
	    
	    for(i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if(map[i][j] == '+') {
	          ent[temp_int].SetAbsis(j);
	          ent[temp_int].SetOrdinat(i);
	          temp_int++;
	        }
	      }
	    }
	    
	    //mencari exit
	    for (i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if (map[i][j] == '=') {
	          count_exit++;
	        }
	      }
	    }
	    temp_int = 0;
	    
	    //memasukkan koordinat exit ke array of Indices
	    ex = new Indices [count_exit];
	    for (i=0; i<count_exit; i++) {
	    	ex[i] = new Indices();
	    }
	    
	    for (i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if(map[i][j] == '=') {
	          ex[temp_int].SetAbsis(j);
	          ex[temp_int].SetOrdinat(i);
	          temp_int++;
	        }
	      }
	    }
	    
	    //menentukan entrance secara acak
	    idx_entrance = rand.nextInt(count_entrance) + 1;
	    
	    // membuat array of visitable
	    boolean[][] IsVisitable;
	    IsVisitable = new boolean [lebar][panjang];
	    for(i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if (map[i][j] == '=' || map[i][j] == '-' || map[i][j] == '+') {
	          IsVisitable[i][j] = true;
	        }
	        else {
	          IsVisitable[i][j] = false;
	        }
	      }
	    }
	    
	    //touring
	    int x = ent[idx_entrance].GetAbsis();
	    int y = ent[idx_entrance].GetOrdinat();
	    System.out.println("Anda baru saja masuk, anda berada di " +  x + "," + y);
	    boolean IsJalanAble[];
	    IsJalanAble = new boolean [4]; // 0 : atas, 1 : kiri, 2 : bawah, 3 : kanan
	    for (i = 0; i < 4; i++) {
	      IsJalanAble[i] = false;
	    }
	    
	    int count_jalan;
	    int n;
	    jalan = true;
	    Indices I;
	    I = new Indices();
	    while (jalan) {
	      System.out.println("Anda berada di " +  x + "," + y);
	      I.SetAbsis(x);
	      I.SetOrdinat(y);
	      for(n = 0; n<banyak_kandang ; n++){
	        if(IsInteractable(I,daftar_kandang[n])){
	          daftar_kandang[n].Inter();
	        }
	      }
	      count_jalan = 0;
	      if ((y>0) && (IsVisitable[y-1][x])) {// di atas bisa jalan?
	        IsJalanAble[0] = true;
	        count_jalan++;
	      } else {
	        IsJalanAble[0] = false;
	      }
	      if((x > 0) && IsVisitable[y][x-1]) {// di kiri bisa jalan?
	        IsJalanAble[1] = true;
	        count_jalan++;
	      } else {
	        IsJalanAble[1] = false;
	      }
	      if ((y < lebar-1) && IsVisitable[y+1][x]) {// di bawah bisa jalan?
	        IsJalanAble[2] = true;
	        count_jalan++;
	      } else {
	        IsJalanAble[2] = false;
	      }
	      if ((x < lebar-1) && IsVisitable[y][x+1]) {// di kanan bisa jalan?
	        IsJalanAble[3] = true;
	        count_jalan++;
	      } else {
	        IsJalanAble[3] = false;
	      }
	      if (count_jalan == 0) {
	        jalan = false;
	      }
	      else {
	        do {
	          n = rand.nextInt(4) + 1;
	        } while (!IsJalanAble[n]);
	        IsVisitable[y][x] = false;
	        switch (n) {
	          case 0: y--;break;
	          case 1: x--;break;
	          case 2: y++;break;
	          case 3: x++;break;
	          default: jalan=false;
	        }
	      }
	    }
	    //end touring
	    
	    //cek apakah berhenti di exit
	    boolean IsExit = false;
	    int z;
	    for (i = 0; i < count_exit; i++) {
	      if(ex[i].GetAbsis() == x && ex[i].GetOrdinat() == y){
	        IsExit = true;
	      }
	    }
	    if (IsExit) {
	      System.out.println("yeeeyeyeyyey keluar!!!");
	      System.out.println("Anda berada di " +  x + "," + y);
	    }
	    else {
	      System.out.println("noonononono kejebak!!!");
	      System.out.println("Anda berada di " +  x + "," + y);
	    }
 }

}
