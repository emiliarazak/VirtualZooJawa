package indices;
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class IndicesTest {
	private Indices ind = new Indices (5,6);
	private Indices in = new Indices();
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}
	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}
	@Test
	public void testIndicesIntInt() {
		assertEquals("Constructor Indices parameter 1 Error!", 5, ind.GetAbsis());
		assertEquals("Constructor Indices parameter 2 Error!", 6, ind.GetOrdinat());
	}
	@Test
	public void testCopyIndices() {
		in.CopyIndices(ind);
		assertEquals("Constructor Indices parameter 1 Error!", 5, in.GetAbsis());
		assertEquals("Constructor Indices parameter 2 Error!", 6, in.GetOrdinat());
	}
	@Test
	public void testGetAbsis() {
		assertEquals("GetAbsis() Error!", 5, ind.GetAbsis());
	}
	@Test
	public void testGetOrdinat() {
		assertEquals("GetOrdinat() Error!", 6, ind.GetOrdinat());
	}
	@Test
	public void testSetAbsis() {
		ind.SetAbsis(3);
		assertEquals("SetAbsis() Error!", 3, ind.GetAbsis());
		ind.SetAbsis(5);
	}
	@Test
	public void testSetOrdinat() {
		ind.SetOrdinat(4);
		assertEquals("SetOrdinat() Error!", 4, ind.GetOrdinat());
		ind.SetOrdinat(6);
	}
	@Test
	public void testIsEqual() {
		in.CopyIndices(ind);
		assertEquals("IsEqual() Error!", true, ind.IsEqual(in));
	}
	@Test
	public void testPrintKoordinat() {
		ind.PrintKoordinat();
		assertEquals("PrintKoordinat() Error!", "(" + 5 + ", " + 6 + ")\n", outContent.toString());
	}
}