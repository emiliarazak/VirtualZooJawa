package cage;
import static org.junit.Assert.*;
import org.junit.Test;
import indices.Indices;
import animal.Animal;

public class CageTest {
	@Test
	public void testCageIndicesArrayInt() {
		System.out.println("Constructor");
	}

	@Test
	public void testIsHostOf() {
		int i;
	    System.out.println("IsHostOf");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
	    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
	    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
	    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    Indices test;
	    test = new Indices(4,5);
	    
	    assertEquals("Salah IsHostOf", false, instance.IsHostOf(test));
	}

	@Test
	public void testSpacious() {
		int i;
	    System.out.println("Spacious");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
	    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
	    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
	    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    assertEquals("Salah spacious", true, instance.Spacious());
	}

	@Test
	public void testAddAnimal() {
		int i;
	    System.out.println("AddAnimal");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
	    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
	    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
	    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    Animal test = new Animal('K', 2000, 0, 0, 2, false, true, false, false);
	    instance.AddAnimal(test);
	   // System.out.println(instance.GetAnimals()[0].render());
	    //instance.GetAnimals()[0].Interact();
	    assertEquals("Salah addAnimals", 1, instance.GetBanyakHewan());
	}

	@Test
	public void testInter() {
		System.out.println("Inter");
	}

	@Test
	public void testGetAnimals() {
		int i;
	    System.out.println("GetAnimal");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
	    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
	    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
	    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    Animal test = new Animal('K', 2000, 0, 0, 2, false, true, false, false);
	    instance.AddAnimal(test);
	    
	    assertEquals("Salah GetAnimal test render", test.render(), instance.GetAnimals()[0].render());
	    assertEquals("Salah GetAnimal test berat", test.GetBerat(), instance.GetAnimals()[0].GetBerat());
	     
	}

	@Test
	public void testGetLuas() {
		int i;
	    System.out.println("GetLuas");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
	    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
	    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
	    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    assertEquals("Salah luas", 4, instance.GetLuas());
	}

	@Test
	public void testGetBanyakHewan() {
		int i;
	    System.out.println("GetBanyakHewan");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
	    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
	    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
	    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    assertEquals("Salah banyak_hewan", 0, instance.GetBanyakHewan());
	}

	@Test
	public void testGetWilayah() {
		int i;
	    System.out.println("GetWilayah");
	    Indices[] ind;
	    ind = new Indices[4];
	    for (i=0; i<4; i++) {
	      ind[i] = new Indices();
	    }
	    
	    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
	    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
	    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
	    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
	    
	    Cage instance = new Cage(ind,4);
	    
	    assertEquals("Salah wilayah 1 absis", 0, instance.GetWilayah()[0].GetAbsis());
	    assertEquals("Salah wilayah 1 ordinat", 0, instance.GetWilayah()[0].GetOrdinat());
	    assertEquals("Salah wilayah 2 absis", 0, instance.GetWilayah()[1].GetAbsis());
	    assertEquals("Salah wilayah 2 ordinat", 1, instance.GetWilayah()[1].GetOrdinat());
	    assertEquals("Salah wilayah 3 absis", 1, instance.GetWilayah()[2].GetAbsis());
	    assertEquals("Salah wilayah 3 ordinat", 0, instance.GetWilayah()[2].GetOrdinat());
	    assertEquals("Salah wilayah 4 absis", 1, instance.GetWilayah()[3].GetAbsis());
	    assertEquals("Salah wilayah 4 ordinat", 1, instance.GetWilayah()[3].GetOrdinat());
	    
	}

	@Test
	public void testCopyCage() {
		 System.out.println("CopyCage");
	}

}