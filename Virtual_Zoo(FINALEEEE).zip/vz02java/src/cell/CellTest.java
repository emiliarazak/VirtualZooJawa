package cell;

import static org.junit.Assert.*;

import org.junit.Test;

import indices.Indices;

public class CellTest {
	private Indices ind = new Indices(5,6);
	private Cell c = new Cell (ind, 'a');
	@Test
	public void testCellIndicesChar() {
		assertEquals("Constructor Cell Parameter 1 Error!", 5, c.GetKoordinat().GetAbsis());
		assertEquals("Constructor Cell Parameter 1 Error!", 6, c.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Cell Parameter 2 Error!", 'a', c.GetCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat() Error!", 5, c.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat() Error!", 6, c.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("IsHabitat() Error!", true, c.IsHabitat());
	}

	@Test
	public void testIsFacility() {
		assertEquals("IsFacility() Error!", false, c.IsFacility());
	}

	@Test
	public void testGetCode() {
		assertEquals("GetCode() Error!", 'a', c.GetCode());
	}

	@Test
	public void testIsRoad() {
		assertEquals("IsRoad() Error!", false, c.IsRoad());
	}

	@Test
	public void testIsPark() {
		assertEquals("IsPark() Error!", false, c.IsPark());
	}

	@Test
	public void testIsRestaurant() {
		assertEquals("IsRestaurant() Error!", false, c.IsRestaurant());
	}

	@Test
	public void testIsLand() {
		assertEquals("IsLand() Error!", false, c.IsLand());
	}

	@Test
	public void testIsWater() {
		assertEquals("IsWater() Error!", false, c.IsWater());
	}

	@Test
	public void testIsAir() {
		assertEquals("IsAir() Error!", true, c.IsAir());
	}

	@Test
	public void testRender() {
		assertEquals("Render() Error!", 'a', c.render());
	}
}