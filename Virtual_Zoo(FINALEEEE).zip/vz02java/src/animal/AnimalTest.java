package animal;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AnimalTest {
  private Animal a = new Animal('K', 2000, 3, 4, 2, false, true, false, false);
  private Animal b = new Animal();
  private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
  @Before
  public void setUpStreams() {
    System.setOut(new PrintStream(outContent));
  }
  @After
  public void cleanUpStreams() {
    System.setOut(null);
  }
  @Test
  public void testAnimalCharIntIntIntIntBooleanBooleanBooleanBoolean() {
    assertEquals("Constructor Animal parameter 1 Error!", 'K', a.render());
    assertEquals("Constructor Animal parameter 2 Error!", 2000, a.GetBerat());
    assertEquals("Constructor Animal parameter 3 Error!", 3, a.GetKoordinat().GetAbsis());
    assertEquals("Constructor Animal parameter 4 Error!", 4, a.GetKoordinat().GetOrdinat());
    assertEquals("Constructor Animal parameter 5 Error!", 2, a.GetMakanan());
    assertEquals("Constructor Animal parameter 6 Error!", false, a.IsLandAnimal());
    assertEquals("Constructor Animal parameter 7 Error!", true, a.IsWaterAnimal());
    assertEquals("Constructor Animal parameter 8 Error!", false, a.IsAirAnimal());
    assertEquals("Constructor Animal parameter 9 Error!", false, a.IsJinak());
  }
  @Test
  public void testInteract() {
    a.Interact();
    assertEquals("Interact() Error!", "*Big grins* heyyo\n", outContent.toString());
  }
  @Test
  public void testGetBerat() {
    assertEquals("GetBerat() Error!", 2000, a.GetBerat());
  }
  @Test
  public void testSetBerat() {
    a.SetBerat(1500);
    assertEquals("SetBerat() Error!", 1500, a.GetBerat());
    a.SetBerat(2000);
  }
  @Test
  public void testGetKoordinat() {
    assertEquals("GetKoordinat() Error!", 3, a.GetKoordinat().GetAbsis());
    assertEquals("GetKoordinat() Error!", 4, a.GetKoordinat().GetOrdinat());
  }
  @Test
  public void testSetKoordinat() {
    a.SetKoordinat(5,6);
    assertEquals("SetKoordinat() Error!", 5, a.GetKoordinat().GetAbsis());
    assertEquals("SetKoordinat() Error!", 6, a.GetKoordinat().GetOrdinat());
    a.SetKoordinat(3,4);
  }
  @Test
  public void testIsLandAnimal() {
    assertEquals("IsLandAnimal() Error!", false, a.IsLandAnimal());
  }

  @Test
  public void testIsWaterAnimal() {
    assertEquals("IsWaterAnimal() Error!", true, a.IsWaterAnimal());
  }

  @Test
  public void testIsAirAnimal() {
    assertEquals("IsAirAnimal() Error!", false, a.IsAirAnimal());
  }

  @Test
  public void testIsJinak() {
    assertEquals("IsJinak() Error!", false, a.IsJinak());
  }

  @Test
  public void testGetMakanan() {
    assertEquals("GetMakanan() Error!", 2, a.GetMakanan());
  }

  @Test
  public void testCopyAnimal() {
    b.CopyAnimal(a);
    assertEquals("Copy Animal parameter 1 Error!", 'K', b.render());
    assertEquals("Copy Animal parameter 2 Error!", 2000, b.GetBerat());
    assertEquals("Copy Animal parameter 3 Error!", 3, b.GetKoordinat().GetAbsis());
    assertEquals("Copy Animal parameter 4 Error!", 4, b.GetKoordinat().GetOrdinat());
    assertEquals("Copy Animal parameter 5 Error!", 2, b.GetMakanan());
    assertEquals("Copy Animal parameter 6 Error!", false, b.IsLandAnimal());
    assertEquals("Copy Animal parameter 7 Error!", true, b.IsWaterAnimal());
    assertEquals("Copy Animal parameter 8 Error!", false, b.IsAirAnimal());
    assertEquals("Copy Animal parameter 9 Error!", false, b.IsJinak());
  }

  @Test
  public void testRender() {
    assertEquals("render() Error!", 'K', a.render());
  }
}