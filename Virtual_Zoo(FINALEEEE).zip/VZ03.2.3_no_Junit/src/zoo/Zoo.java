package zoo;

/**
 * @author aliviaprht
 * @version 3.0
 * @since 24-03-2017
 */

import animal.Animal;
import animal.anseriformes.duck.Duck;
import animal.anseriformes.swan.Swan;
import animal.artiodactyls.deer.Deer;
import animal.artiodactyls.giraffe.Giraffe;
import animal.carnivora.lion.Lion;
import animal.carnivora.meerkat.Meerkat;
import animal.carnivora.wolf.Wolf;
import animal.casuariformes.cassowary.Cassowary;
import animal.cetacea.beluga.Beluga;
import animal.cetacea.dolphin.Dolphin;
import animal.primates.gorilla.Gorilla;
import animal.primates.lemur.Lemur;
import animal.primates.monkey.Monkey;
import animal.psittaciformes.cockatoo.Cockatoo;
import animal.psittaciformes.parrot.Parrot;
import animal.selachimorpha.greatwhiteshark.GreatWhiteShark;
import animal.squamata.chameleon.Chameleon;
import animal.squamata.python.Python;
import animal.strigiformes.owl.Owl;
import cage.Cage;
import cell.Cell;
import cell.facility.park.Park;
import cell.facility.restaurant.Restaurant;
import cell.facility.road.Road;
import cell.habitat.airhabitat.AirHabitat;
import cell.habitat.landhabitat.LandHabitat;
import cell.habitat.waterhabitat.WaterHabitat;
import indices.Indices;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

public class Zoo {
  //Atribut
  
  /**  Atribut map adalah Matriks of Cell.
   */
  private Cell[][] map;
  /**  Atribut daftarKandang adalah Array of Cage yang dimiliki kebun binatang.
   */
  private Cage[] daftarKandang;
  /**  Atribut lebar adalah lebar dari kebun binatang.
    */
  private int lebar;
  /**  Atribut panjang adalah panjang dari kebun binatang.
    */
  private int panjang;
  /**  Atribut banyakKandang adalah jumlah kandang yang ada di kebun binatang.
    */
  private int banyakKandang;
  /**  Atribut readyToPrint adalah Matriks of character kebun binatang yang siap dicetak ke layar (sudah ada hewan).
    */
  private char[][] readyToPrint;
  /**  Atribut baseMap adalah Matriks of character kebun binatang hasil render habitat (belum ada hewan).
    */
  private char[][] baseMap;
  
  //Method
  /** Constructor dari Zoo.
    * Menghidupkan kebun binatang
    */
  public Zoo() throws IOException {
    int inputLebar = 0;
    int inputPanjang = 0;
    int inputBanyakKandang = 0;
    int i;
    int j;
    int k;
    
    BufferedReader br = new BufferedReader(new FileReader("src/zoo/map.txt"));
    String strLine;
    strLine = br.readLine();
    for (i = 0; i < strLine.length(); i++) {
      inputLebar = (inputLebar * 10) + ((int) strLine.charAt(i) - 48);
    }
    strLine = br.readLine();
    for (i = 0; i < strLine.length(); i++) {
      inputPanjang = (inputPanjang * 10) + ((int) strLine.charAt(i) - 48);
    }
    strLine = br.readLine();
    for (i = 0; i < strLine.length(); i++) {
      inputBanyakKandang = (inputBanyakKandang * 10) + ((int) strLine.charAt(i) - 48);
    }
    Indices[][] tempIndices;
    tempIndices = new Indices[inputBanyakKandang][25];
    for (i = 0; i < inputBanyakKandang; i++) {
      for (j = 0; j < 25; j++) {
        tempIndices[i][j] = new Indices();
      }
    }
    lebar = inputLebar;
    panjang = inputPanjang;
    map = new Cell[lebar][panjang];
    banyakKandang = inputBanyakKandang;
    int[] neffKandang;
    neffKandang = new int[banyakKandang];
    for (i = 0; i < banyakKandang; i++) {
      neffKandang[i] = 0;
    } 
    char habitat;
    int code;
    Indices ind;
    ind = new Indices(0,0);
    for (i = 0; i < lebar; i++) {
      strLine = br.readLine();
      j = 0;
      k = 0;
      while (j < inputPanjang * 2) {
        ind.setAbsis(k);
        ind.setOrdinat(i);
        habitat = strLine.charAt(j);
        if (habitat == 'W') {
          map[i][k] = new WaterHabitat(ind);
        } else if (habitat == 'L') {
          map[i][k] = new LandHabitat(ind);
        } else if (habitat == 'A') {
          map[i][k] = new AirHabitat(ind);
        } else if (habitat == '-') {
          map[i][k] = new Road(ind, 0);
        } else if (habitat == '+') {
          map[i][k] = new Road(ind, 1);
        } else if (habitat == '=') {
          map[i][k] = new Road(ind, 2);
        } else if (habitat == 'P') {
          map[i][k] = new Park(ind);
        } else if (habitat == 'R') {
          map[i][k] = new Restaurant(ind);
        } else {
          //do nothing
        }
        j++;
        k++;
        code = ((int) strLine.charAt(j) - 48);
        if (code != 0) {
          tempIndices[code - 1][neffKandang[code - 1]].copyIndices(ind);
          neffKandang[code - 1]++;
        }
        j++;
      }
    }
    br.close();
    daftarKandang = new Cage[banyakKandang];
    Indices[] tempIndicesInput;
    for (i = 0; i < banyakKandang; i++) {
      tempIndicesInput = new Indices[25];
      for (j = 0; j < 25; j++) {
        tempIndicesInput[j] = new Indices();
      }
      for (j = 0; j < neffKandang[i]; j++) {
        tempIndicesInput[j].copyIndices(tempIndices[i][j]);
      }
      daftarKandang[i] = new Cage(tempIndicesInput,neffKandang[i]);
    }
    baseMap = new char[lebar][panjang];
    readyToPrint = new char[lebar][panjang];
    for (i = 0; i < lebar; i++) {
      for (j = 0; j < panjang; j++) {
        baseMap[i][j] = map[i][j].render();
        readyToPrint[i][j] = baseMap[i][j];
      }
    }
    //Memasukkan Binatang
    Animal[] animalInput;
    animalInput = new Animal[37];
    i = 0;
    //Cage 1
    animalInput[i] = new Beluga(45,2,2);
    daftarKandang[0].addAnimal(animalInput[i]);
    animalInput[i] = new Dolphin(45,1,1);
    daftarKandang[0].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Swan(45,0,0);
    daftarKandang[0].addAnimal(animalInput[i]);
    i++;
    //Cage 2
    animalInput[i] = new Cockatoo(10,19,0);
    daftarKandang[1].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Cockatoo(10,8,2);
    daftarKandang[1].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Parrot(10,17,0);
    daftarKandang[1].addAnimal(animalInput[i]);
    i++;
    //Cage 3
    animalInput[i] = new Lion(100, 1, 4);
    daftarKandang[2].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Lion(100, 1, 5);
    daftarKandang[2].addAnimal(animalInput[i]);
    i++;
    //Cage 4
    animalInput[i] = new Cassowary(70, 6, 4);
    daftarKandang[3].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Monkey(30, 6, 6);
    daftarKandang[3].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Deer(60, 7, 5);
    daftarKandang[3].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Lemur(30,5,7);
    daftarKandang[3]. addAnimal(animalInput[i]);
    i++;
    //Cage 5
    animalInput[i] = new Giraffe(100,14,4);
    daftarKandang[4].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Meerkat(30, 14, 6);
    daftarKandang[4].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Owl(10, 16, 4);
    daftarKandang[4].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Chameleon(15, 12, 6);
    daftarKandang[4].addAnimal(animalInput[i]);
    i++;
    //Cage 6
    animalInput[i] = new Wolf(70, 18, 8);
    daftarKandang[5].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Wolf(70, 19, 6);
    daftarKandang[5].addAnimal(animalInput[i]);
    i++;
    //Cage 7
    animalInput[i] = new Gorilla(100, 10, 12);
    daftarKandang[6].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Duck(10, 14, 11);
    daftarKandang[6].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Swan(10, 12, 12);
    daftarKandang[6].addAnimal(animalInput[i]);
    i++;
    //Cage 8
    animalInput[i] = new GreatWhiteShark(150, 5, 19);
    daftarKandang[7].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new GreatWhiteShark(150, 7, 16);
    daftarKandang[7].addAnimal(animalInput[i]);
    i++;
    //Cage 9
    animalInput[i] = new Python(100, 11, 18);
    daftarKandang[8].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Python(100, 12, 16);
    daftarKandang[8].addAnimal(animalInput[i]);
    i++;
    animalInput[i] = new Python(100, 12, 19);
    daftarKandang[8].addAnimal(animalInput[i]);
    i++;   
    int absisHewan;
    int ordinatHewan;
    for (i = 0; i < banyakKandang; i++) {
      for (j = 0; j < daftarKandang[i].getBanyakHewan(); j++) {
        absisHewan = daftarKandang[i].getAnimals()[j].getKoordinat().getAbsis();
        ordinatHewan = daftarKandang[i].getAnimals()[j].getKoordinat().getOrdinat();
        readyToPrint[ordinatHewan][absisHewan] = daftarKandang[i].getAnimals()[j].render();
      }
    }
  }
  
  /** Mengembalikan nilai booleanean apakah hewan dapat tinggal pada Cell C.
   * 
   * @param c Cell yang dicek untuk hewan dapat tinggal atau tidak.
   * @param a Animal yang dicek.
   * @return boolean
   */
  
  public boolean isLivable(Animal a, Cell c) {
    if (c.isHabitat()) {
      return ((c.getCode() == 'l') && (a.isLandAnimal()))
        || ((c.getCode() == 'w') && (a.isWaterAnimal()))
        || ((c.getCode() == 'a') && (a.isAirAnimal()));
    } else {
      return false;
    }
  }
  
  /** Prosedur moved.
   * I.S Semua elemen dalam kebun binatang telah dihidupkan
   * F.S Semua Animals dalam berpindah tempat
   * Menggerakkan hewan yang ada didalam kebun binatang
   */
  
  public void move() {
    boolean moved;
    Indices ind;
    int count;
    int x;
    int y;
    int to;
    int toX;
    int toY;
    Random rand = new Random();
    ind = new Indices();
    for (int i = 0; i < banyakKandang; i++) {
      for (int j = 0; j < daftarKandang[i].getBanyakHewan(); j++) {
        moved = false;
        count = 0;
        x = (daftarKandang[i].getAnimals()[j]).getKoordinat().getAbsis();
        y = (daftarKandang[i].getAnimals()[j]).getKoordinat().getOrdinat();
        to = rand.nextInt(4) + 1;
        while ((!(moved)) && (count < 4)) {
          toX = x;
          toY = y;
          count++;
          switch (to) {
            case 1 : {
              toX++;
            };
            break;
            case 2 : {
              toY++;
            };
            break;
            case 3 : {
              toX--;
            };
            break; 
            case 4 : {
              toY--;
            };
            break;
            default : {
              //do nothing
            }
          }
          if ((toY >= 0) && (toY < lebar) && (toX >= 0) && (toX < panjang)) {
            ind.setOrdinat(toY);
            ind.setAbsis(toX);
            if ((isLivable(daftarKandang[i].getAnimals()[j],map[toX][toY]))
                && (daftarKandang[i].isHostOf(ind)) && ((readyToPrint[toY][toX] == 'w')
                || (readyToPrint[toY][toX] == 'l') || (readyToPrint[toY][toX] == 'a'))) {
              moved = true;
              (daftarKandang[i].getAnimals()[j]).setKoordinat(toX, toY);
              readyToPrint[y][x] = baseMap[y][x];
              readyToPrint[toY][toX] = (daftarKandang[i].getAnimals()[j]).render();
            } else {
              to = (to % 4) + 1;
            }
          } else {
            to = (to % 4) + 1;
          }
        }        
      }
    } 
  }
 
  /**  Prosedur print.
   * <br>
   * <br>I.S Zoo telah hidup. 
   * <br>F.S Semua elemen zoo tercetak pada layar. 
   * <br>Mencetak kebun binatang beserta seluruh elemennya ke layar.
   */
  
  public void print() {
    for (int i = 0; i < lebar; i++) {
      for (int j = 0; j < panjang; j++) {
        System.out.print(readyToPrint[i][j]);
        System.out.print(" ");
      }
      System.out.println();
    }
  }
  
  /**  Prosedur Hitung Makanan.<br>
   * I.S Zoo telah hidup.<br>
   * F.S Jumlah makanan yang dibutuhkan kebun binatang setiap harinya tercetak di layar.<br>
   * Mengkalkulasikan jumlah makanan yang diperlukan hewan-hewan yang hidup di kebun binatang.<br>
   * Mencetak hasil kalkulasi jumlah makanan ke layar
   */
  
  public void hitungMakanan() {
    int sayurBuahDanBiji2an = 0;
    int daging = 0;
    int i;
    int j;
    for (i = 0; i < banyakKandang; i++) {
      for (j = 0; j < daftarKandang[i].getBanyakHewan(); j++) {
        if (daftarKandang[i].getAnimals()[j].getMakanan() == 0) {
          sayurBuahDanBiji2an = sayurBuahDanBiji2an + (daftarKandang[i].getAnimals()[j].getBerat() * 3 / 100);        
        } else if (daftarKandang[i].getAnimals()[j].getMakanan() == 1) {
          sayurBuahDanBiji2an = sayurBuahDanBiji2an + (daftarKandang[i].getAnimals()[j].getBerat() * 3 / 200);
          daging = daging + (daftarKandang[i].getAnimals()[j].getBerat() * 3 / 200);
        } else if (daftarKandang[i].getAnimals()[j].getMakanan() == 2) {
          daging = daging + (daftarKandang[i].getAnimals()[j].getBerat() * 3 / 100);
        }
      }
    }
    System.out.println("Butuh daging sebanyak " + daging + "kg.");
    System.out.println("Butuh sayur,buah, dan biji-bijian sebanyak " + sayurBuahDanBiji2an + "kg.");
  }
  /**  Mengembalikan bool apakah indeks tertentu bersinggungan dengan sebuah kandang.
   *
   * @param ind adalah indeks yang akan diperiksa
   * @param c adalah kandang yang akan diperiksa
   * @return boolean
   */

  public boolean isInteractable(Indices ind, Cage c) {
    Indices it;
    it = new Indices();
    it.setAbsis(ind.getAbsis() + 1);
    it.setOrdinat(ind.getOrdinat());
    boolean iya = false;
    iya = (c.isHostOf(it));
    if (!iya) {
      it.setAbsis(ind.getAbsis() - 1);
      it.setOrdinat(ind.getOrdinat());
      iya = (c.isHostOf(it));
    }
    if (!iya) {
      it.setAbsis(ind.getAbsis());
      it.setOrdinat(ind.getOrdinat() + 1);
      iya = (c.isHostOf(it));
    }
    if (!iya) {
      it.setAbsis(ind.getAbsis());
      it.setOrdinat(ind.getOrdinat() - 1);
      iya = (c.isHostOf(it));
    }
    return iya;
  }
  /** Getter daftar kandang pada zoo.
   * @return array of cage
   */
  
  public Cage[] getKandang() {
    return daftarKandang;
  }
  
  /** Getter readyToPrint pada zoo.
   * @return matriks of char 
   */
  public char[][] getPrint() {
    return readyToPrint;
  }
 
  /** Melakukan tour pada zoo
   * I.S Semua elemen pada zoo terdefinisi
   * F.S Melakukan tour di zoo dan berinteraksi pada tiap animal yang dilewati
   */
  
  public void tour() {
    Random rand = new Random();
    int countEntrance;
    int countExit;
    int j;
    int tempInt = 0;
    char[][] map;
    countEntrance = 0;
    countExit = 0;
    map = new char [lebar][panjang];
    int i;
    //mindahin map di zoo ke temp map
    for (i = 0; i < lebar; i++) {
      for (j = 0; j < panjang; j++) {
        map[i][j] = readyToPrint[i][j];
      }
    }
    //mencari entrance
    for (i = 0; i < lebar; i++) {
      for (j = 0; j < panjang; j++) {
        if (map[i][j] == '+') {
          countEntrance++;
        }
      }
    }
    //memasukkan koordinat entrance ke array of Indices
    Indices[] ent;
    ent = new Indices [countEntrance];
    for (i = 0; i < countEntrance; i++) {
      ent[i] = new Indices();
    }    
    for (i = 0; i < lebar; i++) {
      for (j = 0; j < panjang; j++) {
        if (map[i][j] == '+') {
          ent[tempInt].setAbsis(j);
          ent[tempInt].setOrdinat(i);
          tempInt++;
        }
      }
    }
    //mencari exit
    for (i = 0; i < lebar; i++) {
      for (j = 0; j < panjang; j++) {
        if (map[i][j] == '=') {
          countExit++;
        }
      }
    }
    tempInt = 0;
    //memasukkan koordinat exit ke array of Indices
    Indices[] ex;
    ex = new Indices [countExit];
    for (i = 0; i < countExit; i++) {
      ex[i] = new Indices();
    }
    for (i = 0; i < lebar; i++) {
      for (j = 0; j < panjang; j++) {
        if (map[i][j] == '=') {
          ex[tempInt].setAbsis(j);
          ex[tempInt].setOrdinat(i);
          tempInt++;
        }
      }
    }
    //menentukan entrance secara acak
    int idxEntrance = 0;
    while (idxEntrance >= (tempInt - 1)) {
      idxEntrance = rand.nextInt(countEntrance) + 1;
    }
    // membuat array of visitable
    boolean[][] isVisitable;
    isVisitable = new boolean [lebar][panjang];
    for (i = 0; i < lebar; i++) {
      for (j = 0; j < panjang; j++) {
        if (map[i][j] == '=' || map[i][j] == '-' || map[i][j] == '+') {
          isVisitable[i][j] = true;
        } else {
          isVisitable[i][j] = false;
        }
      }
    }
    //touring
    int x = ent[idxEntrance].getAbsis();
    int y = ent[idxEntrance].getOrdinat();
    System.out.println("Anda baru saja masuk, anda berada di " +  x + "," + y);
    boolean[] isJalanAble;
    isJalanAble = new boolean [4]; // 0 : atas, 1 : kiri, 2 : bawah, 3 : kanan
    for (i = 0; i < 4; i++) {
      isJalanAble[i] = false;
    }
    int countJalan;
    int n;
    boolean jalan;
    jalan = true;
    Indices ind;
    ind = new Indices();
    while (jalan) {
      System.out.println("Anda berada di " +  x + "," + y);
      ind.setAbsis(x);
      ind.setOrdinat(y);
      for (n = 0; n < banyakKandang ; n++) {
        if (isInteractable(ind,daftarKandang[n])) {
          daftarKandang[n].inter();
        }
      }
      countJalan = 0;
      if ((y > 0) && (isVisitable[y - 1][x])) {
        // di atas bisa jalan?
        isJalanAble[0] = true;
        countJalan++;
      } else {
        isJalanAble[0] = false;
      }
      if ((x > 0) && isVisitable[y][x - 1]) {
        // di kiri bisa jalan?
        isJalanAble[1] = true;
        countJalan++;
      } else {
        isJalanAble[1] = false;
      }
      if ((y < lebar - 1) && isVisitable[y + 1][x]) {
        // di bawah bisa jalan?
        isJalanAble[2] = true;
        countJalan++;
      } else {
        isJalanAble[2] = false;
      }
      if ((x < lebar - 1) && isVisitable[y][x + 1]) {
        // di kanan bisa jalan?
        isJalanAble[3] = true;
        countJalan++;
      } else {
        isJalanAble[3] = false;
      }
      if (countJalan == 0) {
        jalan = false;
      } else {
        do {
          n = rand.nextInt(4);
        } while (!isJalanAble[n]);
        isVisitable[y][x] = false;
        switch (n) {
          case 0: y--;
          break;
          case 1: x--;
          break;
          case 2: y++;
          break;
          case 3: x++;
          break;
          default: jalan = false;
        }
      }
    }
    //end touring
    //cek apakah berhenti di exit
    boolean isExit = false;
    for (i = 0; i < countExit; i++) {
      if (ex[i].getAbsis() == x && ex[i].getOrdinat() == y) {
        isExit = true;
      }
    }
    if (isExit) {
      System.out.println("yeeeyeyeyyey keluar!!!");
      System.out.println("Anda berada di " +  x + "," + y);
    } else {
      System.out.println("noonononono kejebak!!!");
      System.out.println("Anda berada di " +  x + "," + y);
    }
    System.out.println();
  }
}