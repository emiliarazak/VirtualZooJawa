/**
 * 
 */

package driver;

import java.io.IOException;
import java.util.Scanner;

import zoo.Zoo;

/** Class Driver.
  * @author Luthfi Fadillah
  * 
  */

public class Driver {
  private Zoo zoo;
  private Scanner key;
  
  /** Constructor untuk Driver.
   */
  
  public Driver() {
    try {
      zoo = new Zoo();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }
  
  /** Menampilkan mainMenu.
   */
  
  public void mainMenu() {
    key = new Scanner(System.in);
    int input;
    boolean keluar;
    keluar = false;
    while (!keluar) {
      System.out.println("Selamat Datang Di Virtual Zoo");
      System.out.println("");
      System.out.println("Menu: ");
      System.out.println("1. Display Virtual Zoo (Partial)");
      System.out.println("2. Display Virtual Zoo (Full)");
      System.out.println("3. tour di Virtual Zoo");
      System.out.println("4. Menampilkan Banyak Makanan");
      System.out.println("5. Keluar");
      System.out.println("");
      System.out.print("Input: ");
      input = key.nextInt();
      switch (input) {
        case 1 :
          displayVirtualZoo(input);
          break;
        case 3 :
          tourVirtualZoo();
          break;
        case 4 :
          displayMakanan();
          break;
        case 5 :
          System.out.println("See ya!");
          keluar = true;
          break;
        case 2 :
          displayVirtualZoo(input);
          break;
        default :
          System.out.println("Masukan salah");
      }
    }
  }

  /** Menampilkan Virtual Zoo.
   * @param input : bertipe integer, menyatakan input yang dimasukkan user
   */
  
  public void displayVirtualZoo(int input) {
    key = new Scanner(System.in);
    char n;
    int x1;
    int y1;
    int x2;
    int y2;
    int i;
    int j;
    switch (input) {
      case 1 :
        do {
          System.out.println("Masukkan koordinat atas-kiri ");
          x1 = key.nextInt();
          y1 = key.nextInt();
          System.out.println("Masukkan koordinat bawah-kanan ");
          x2 = key.nextInt();
          y2 = key.nextInt();
          if ((x1 >= x2) || (y1 >= y2)) {
            System.out.println("Masukan koordinat salah");
          }
        } while ((x1 >= x2) || (y1 >= y2));
        
        for (i = x1; i <= x2; i++) {
          for (j = y1; j <= y2; j++) {
            System.out.print(zoo.getPrint()[i][j] + " ");
          }
          System.out.println();
        }
        displayLegend();
        break;
      case 2 :
        do {
          zoo.move();
          zoo.print();
          System.out.println("move? (y/n) ");
          n = key.next().charAt(0);
        } while (n == 'y');
        break;
      default :
        System.out.println("Masukan salah");
    }
  }
  
  /** Melakukan tour pada Virtual Zoo.
    */
  
  public void tourVirtualZoo() {
    zoo.tour();
  }
  
  /** Menampilkan jumlah makanan yang dibutuhkan di kebun binatang dalam satu hari.
    */
  
  public void displayMakanan() {
    zoo.hitungMakanan();
  }
  
  /** Menampilkan legenda.
    */
  
  public void displayLegend() {
    System.out.println();
    System.out.println("Legend");
    System.out.println("B: Beluga" + "\t" + "S: Big Horn Sheep" + "\t" + "C: Cassowary" 
        + "\t" + "H: Chameleon\t" + "T: Cheetah");
    System.out.println("O: Cockatoo" + "\t" + "D: Deer\t\t\t" + "N: Dolphin" + "\t" 
        + "U: Duck\t\t" + "G: Giraffe");
    System.out.println("J: Gorilla\tK: Great White Shark\tE: Lemur\tI: Lion\t\tM: Meerkat");
    System.out.println("Y: Monkey\t$: Orca\t\t\tZ: Owl\t\tX: Parrot\tV: Python");
    System.out.println("Q: Swan\t\tF: Tarsier\t\t@: Wolf\t\tP: Park\t\tR: Restaurant");
    System.out.println("L: Land Habitat\tW: Water Habitat\tA: Air Habitat\t-: Road\t\t+: Entrance");
    System.out.println("=: Exit");
    System.out.println();  
  }
}