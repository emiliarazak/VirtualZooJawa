/**
 * 
 */

package animal.animalclone;

import animal.Animal;

/** Class AnimalClone.
 * @author Suzane Ringoringo
 *
 */

public final class AnimalClone extends Animal {

  /** copyRender untuk mengkopi render.
   *
   */
  private char copyRender;

  /** Constructor untuk AnimalClone.
  *
  */
  
  public AnimalClone(char sourceRender, String sourceInteract) {
    super(0,false,false,false,true,0,0);
    copyRender = sourceRender;
    setInteraction(sourceInteract);
  }
  
  public char render() {
    return copyRender;
  }

}
