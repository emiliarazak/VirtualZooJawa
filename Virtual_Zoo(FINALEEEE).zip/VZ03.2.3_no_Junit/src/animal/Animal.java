/**
 * 
 */

package animal;

import indices.Indices;
import renderable.Renderable;

/** Kelas Animal.
 * 
 * @author Suzane Ringoringo
 *
 */
public abstract class Animal implements Renderable {

  /** Atribut berat_badan  menyatakan berapa berat hewan tersebut.
   */

  protected int beratBadan;
  
  /** Atribut koordinat  adalah letak dimana hewan berada.
   */
  
  protected Indices koordinat;
  
  /** Atribut makanan adalah keterangan klasifikasi hewan berdasarkan makanan.
   * Herbivore=0, Omnivore=1, Carnivore=2.
   */
  
  protected int makanan;
  
  /** Atribut land_animal  adalah boolean yang menyatakan dapatkah hewan tinggal di darat.
   */
  
  protected boolean landAnimal;

  /** Atribut water_animal  adalah boolean yang menyatakan dapatkah hewan tinggal di air.
   */
  
  protected boolean waterAnimal;

  /** Atribut air_animal  adalah boolean yang menyatakan dapatkah hewan tinggal di udara.
   */

  protected boolean airAnimal;

  /** Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya hewan.
   */

  protected boolean jinak;

  /** Atribut species_interaction adalah String.
   * menyatakan bagaimana sebuah spesies berinteraksi.
   */
  
  protected String speciesInteraction;

  /** Constructor tanpa parameter dari Hewan.
   * Menghidupkan hewan.
   *
   * @author Suzane Ringoringo
   */
  
  public Animal() {}
  
  /** Constructor dari Hewan.
   * Menghidupkan hewan.
   * 
   * @param makan integer adalah kode jenis makanan hewan, Herbivore=0, Omnivore=1, Carnivore=2
   * @param land boolean menyatakan apakah hewan dapat hidup di darat
   * @param water boolean menyatakan apakah hewan dapat hidup di air
   * @param air boolean menyatakan apakah hewan dapat hidup di udara
   * @param kejinakan boolean menyatakan jinak tidaknya hewan
   * @param x integer adalah letak absis hewan yang dihidupk
   * @param y integer adalah letak ordinat hewan yang dihidupkan
   */
  
  public Animal(int makan, boolean land, boolean water, boolean air, boolean kejinakan, 
      int x, int y) {
    makanan = makan;
    landAnimal = land;
    waterAnimal = water;
    airAnimal = air;
    jinak = kejinakan;
    koordinat = new Indices();
    koordinat.setAbsis(x);
    koordinat.setOrdinat(y);
    speciesInteraction = "";
  }
  
  /** Prosedur virtual interact dari hewan.
   * I.S : hewan telah dihidupkan.
   * F.S : Mencetak suara hewan kelayar.
   */
  
  public final void interact() {
    System.out.println(speciesInteraction);
  }
  
  /** getBerat dari hewan.
   * Mengembalikan nilai integer berat dari hewan.
   * 
   * @return int
   */
  
  public final int getBerat() {
    return beratBadan;
  }
  
  /** Prosedur setBerat  dari hewan
   * I.S bb adalah berat badan yang valid yaitu lebih dari 0
   * F.S atribut berat badan hewan diubah menjadi bb
   * Merubah nilai berat dari hewan
   *
   * @param bb integer menyatakan input berat badan yang ingin di set
   */
  
  public final void setBerat(int bb) {
    beratBadan = bb;
  }
  
  /** getKoordinat dari hewan.
   * Mengembalikan nilai indices ordinat hewan
   * @return Koordinat
   */
  
  public Indices getKoordinat() {
    return koordinat;
  }
  
  /** Prosedur setKoordinat  dari hewan
   * I.S x dan y adalah koordinat yang valid pada zoo
   * F.S atribut koordinat hewan memiliki absis x dan ordinat y
   * Merubah nilai Koordinat dari hewan
   *
   * @param x integer menyatakan absis yang ingin di set
   * @param y integer menyatakan ordinat yang ingin di set
   */
  
  public void setKoordinat(int x, int y) {
    koordinat.setAbsis(x);
    koordinat.setOrdinat(y);
  }
  
  /** Fungsi isLandAnimal dari hewan.
   * Mengembalikan nilai boolean apakah hewan dapat hidup di Land
   * 
   * @return boolean
   */
  
  public final boolean isLandAnimal() {
    return landAnimal;
  }
  
  /** Fungsi isWaterAnimal dari hewan.
   * Mengembalikan nilai boolean apakah hewan dapat hidup di Water
   *
   * @return boolean
   */
  
  public final boolean isWaterAnimal() {
    return waterAnimal;
  }
  
  /** Fungsi isAirAnimal dari hewan.
   * Mengembalikan nilai boolean apakah hewan dapat hidup di Air
   * 
   * @return boolean
   */ 
  
  public final boolean isAirAnimal() {
    return airAnimal;
  }
  
  /** Fungsi isJinak dari hewan.
   * Mengembalikan nilai boolean apakah hewan jinak
   * @return boolean 
   */
  
  public final boolean isJinak() {
    return jinak;
  }
  
  /** Mengembalikan nilai integer keterangan makanan hewan.
   * 
   * @return int
   */
  
  public final int getMakanan() {
    return makanan;
  }
  
  /** Menyalin ani pada current object.
   * 
   * @param ani adalah Animal yang akan disalin
   */
  
  public final void copyAnimal(Animal ani) {
    landAnimal = ani.landAnimal;
    waterAnimal = ani.waterAnimal;
    airAnimal = ani.airAnimal;
    jinak = ani.jinak;
    makanan = ani.makanan;
    beratBadan = ani.beratBadan;
    koordinat.copyIndices(ani.getKoordinat());
  }
  
  /** Mengatur interaksi sebuah spesies.
   * 
   * @param interaksi sebagai species_interaction
   * 
   */
  
  public final void setInteraction(String interaksi) {
    speciesInteraction = interaksi;
  }
  
  /** Mengembalikan species_interaction sebuah objek turunan Animal.
   * @return interaksi animal
   */
  
  public final String getInteraction() {
    return speciesInteraction;
  }
  
  /** Mengembalikan true jika parameter dan objek memiliki informasi atribut yang sama.
   * @param a animal yang akan dicek
   * @return boolean hasil cek
   */
  
  public final boolean isEqual(Animal a) {
    return ((speciesInteraction.equals(a.speciesInteraction)) && (koordinat.isEqual(a.koordinat)));
  }
  
}
