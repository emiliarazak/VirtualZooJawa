/**
 * 
 */

package animal.psittaciformes.cockatoo;

import animal.psittaciformes.Psittaciformes;
import renderable.Renderable;

/**Real Class Cockatoo.
 * @author Luthfi Fadillah
 *
 */
public class Cockatoo extends Psittaciformes implements Renderable {
  /** Constructor dari Cockatoo.
   * Menghidupkan hewan Cockatoo.
   *
   * @param x : bertipe int, adalah letak absis Cockatoo yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Cockatoo yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Cockatoo yang dihidupkan.
   */
  
  public Cockatoo(int bb, int x, int y) {
    super(true,x,y);
    setBerat(bb);
    setInteraction("Cockatooo... Cockatooo...");
  }

  /** Mengembalikan nilai character kode dari objek Cockatoo.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  
  public char render() {
    return 'O';
  }
}