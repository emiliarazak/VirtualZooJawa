/**
 * 
 */

package animal.squamata.chameleon;

import animal.squamata.Squamata;

/** Kelas spesies Chameleon.
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Chameleon extends Squamata {
  /** Constructor dari Chameleon.
   * Menghidupkan hewan Chameleon
   *
   * @param x integer adalah letak absis Chameleon yang dihidupkan
   * @param y integer adalah letak ordinat Chameleon yang dihidupkan
   * @param bb integer adalah berat badan Chameleon yang dihidupkan
   */
  public Chameleon(int bb, int x, int y) {
    super(true, x, y);
    setBerat(bb);
    setInteraction("Smisshy slimy smissh");
  }

  @Override
  /** fungsi Render dari objek Chameleon
    * Mengembalikan kode Chameleon pada layar
    * 
    * @return char
    */
  public char render() {
    return 'H';
  }
  
  
}
