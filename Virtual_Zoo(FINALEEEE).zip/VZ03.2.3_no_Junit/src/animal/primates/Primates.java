/**
 * 
 */

package animal.primates;

import animal.Animal;

/** Kelas ordo Primates.
 * 
 * @author Suzane Ringoringo
 *
 */
public abstract class Primates extends Animal {
  /** Constructor dari Primates.
   * Menghidupkan hewan Ordo Primates.
   *
   * @param x integer adalah letak absis Primates yang dihidupkan
   * @param y integer adalah letak ordinat Primates yang dihidupkan
   * @param kejinakan boolean menyatakan jinak tidaknya hewan
   */
  
  public Primates(boolean kejinakan, int x, int y) {
    super(1, true, false, false,kejinakan,x,y);
  }
}
