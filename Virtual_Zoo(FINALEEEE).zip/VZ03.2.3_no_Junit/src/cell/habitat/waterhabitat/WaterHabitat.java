/*
 * To change this license header, choose License Headers in Project Properties.*/

package cell.habitat.waterhabitat;

import cell.habitat.Habitat;
import indices.Indices;

/** Real Class WaterHabitat.
*
* @author Emil
*/

public class WaterHabitat extends Habitat {

  /** Constructor dari Water Habitat.
   * Menghidupkan habitat air
   *
   * @param ind Indices adalah alamat dimana habitat dihidupkan
   */

  public WaterHabitat(Indices ind) {
    super(ind, 1, 'w');
  }
  
  /** Mengembalikan nilai character kode dari objek Water Habitat.
   * Character ini nantinya yang siap dicetak ke layar
   */
  
  public char render() {
    return 'w';
  }
}