/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cell.habitat;

import cell.Cell;
import indices.Indices;

/** Abstract Class Habitat.
*
* @author Emil
*/
public abstract class Habitat extends Cell {

  /** Attribut Htype yang adalah type dari habitat.
   */

  protected int htype;
  
  /** Constructor dari Habitat.
   * Menghidupkan habitat
   *
   * @param ind Indices adalah alamat dimana habitat dihidupkan
   * @param type integer adalah kode dari habitat dimana 0=Land, 1=Water, 2=Air
   * @param code character adalah suatu huruf untuk merepresentasikan habitat di layar.
   */
  
  public Habitat(Indices ind, int type, char code) {
    super(ind, 0, code);
    htype = type;
  }
  
  /** Mengembalikan nilai boolean apakah habitat adalah land.
   */
  
  public final boolean isLand() {
    return (htype == 0);
  }
  
  /** Mengembalikan nilai boolean apakah habitat adalah water.
   */
  
  public final boolean isWater() {
    return (htype == 1);
  }
  
  /** Mengembalikan nilai boolean apakah habitat adalah air.
   */
  
  public final boolean isAir() {
    return (htype == 2);
  }
}