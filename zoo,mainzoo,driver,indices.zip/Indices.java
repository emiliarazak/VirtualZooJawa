package indices;

/**
 * @author Suzane Ringoringo
 * @version 2.0
 * @since 2017-03-28
 */

public class Indices {

  /** Attribut x adalah nilai absis indeks.
   */
  
  protected int absis;
  
  /** Attribut y adalah nilai ordinat indeks.
   */
  
  protected int ordinat;
  
  /** Constructor tanpa parameter dari Indices,
   * Menghidupkan indeks.
   * 
   */
  
  public Indices() {
    absis = 0;
    ordinat = 0;
  }
  
  /** Constructor dengan parameter dari Indices,
   * Menghidupkan indeks sesuai parameter.
   *
   * @param absis integer adalah absis yang akan di set
   * @param ordinat integer adalah ordinat yang akan di set
   * 
   */
  
  public Indices(int absis, int ordinat) {
    this.absis = absis;
    this.ordinat = ordinat;
  }
  
  /** Operator overloading = dari Indices,
   * Memastikan bukan bitewise copy.
   *
   * @param ind menyatakan Indices yang ingin disalin
   * 
   */
  
  public void copyIndices(Indices ind) {
    absis = ind.getAbsis();
    ordinat = ind.getOrdinat();
  }
  
  /** getAbsis dari Indices,
   * Mengembalikan nilai absis dari indeks.
   *@return integer absis
   */
  
  public int getAbsis() {
    return absis;
  }
  
  /** getOrdinat dari Indices,
   * Mengembalikan nilai ordinat dari indeks.
   * @return integer ordinat
   */
  
  public int getOrdinat() {
    return ordinat;
  }
  
  /** Prosedur setAbsis dari Indices
   * I.S Indices sudah hidup dan masukan terdefinisi
   * F.S Absis indices nilai menjadi masukan
   *
   * @param x integer adalah nilai absis yang akan di set
   * 
   */
  
  public void setAbsis(int x) {
    this.absis = x;
  }
  /** Prosedur setOrdinat dari Indices
   * I.S Indices sudah hidup dan masukan terdefinisi
   * F.S Ordinat indices nilai menjadi masukan
   *
   * @param y integer adalah nilai ordinat yang akan di set
   */
  
  public void setOrdinat(int y) {
    this.ordinat = y;
  }
  
  /** Mengembalikan nilai boolean apakah Indices masukan sama dengan current objek.
   *
   * @param ind Indices yang ingin dibandingkan dengan current objek
   * @return boolean
   */
  
  public boolean isEqual(Indices ind) {
    return ((this.absis == ind.getAbsis()) && (this.ordinat == ind.getOrdinat()));
  }
  
  public void printKoordinat() {
    System.out.println("(" + absis + ", " + ordinat + ")");
  }

}
