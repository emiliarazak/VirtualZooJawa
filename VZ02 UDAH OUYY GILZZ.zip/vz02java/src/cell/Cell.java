package cell;
import indices.Indices;
/** Kelas Cell tanpa inheritance
 * 
 * @author alivia
 *
 */


public class Cell {
  //atribut
	/** Atribut koordinat yang adalah Indices letak Cell
	  */
	  Indices koordinat;
	/** Atribut code yang adalah code dari Cell
	  */
	  char code;
	
  //method
	  /**  Constructor tanpa parameter dari Cell
	    * Menghidupkan Cell
	    */
	  public Cell(){}
	  /**  Constructor dari Cell
	    * Menghidupkan Cell
	    *
	    * @param I Indices adalah alamat dimana Cell dihidupkan
	    */
	  public Cell(Indices I, char c){
		  code = c;
		  koordinat = I;
	  }
	  /**  Mengembalikan nilai Indices dimana Cell berada
	    */
	  public Indices GetKoordinat(){
		  return koordinat;
	  }
	  /**  Mengembalikan nilai booleanean apakah Cell adalah habitat
	    */
	  public boolean IsHabitat(){
		  return ((code == 'l')|| (code == 'w') || (code == 'a'));
	  }
	  /**  Mengembalikan nilai booleanean apakah Cell adalah fasilitas
	    */
	  public boolean IsFacility(){
		  return ((code == 'P')|| (code == 'R') || (code == 'S'));
	  }
	  /**  Mengembalikan nilai char Code yang adalah atribut Cell
	    */
	  public char GetCode(){
		  return code;
	  }
	  /**  Mengembalikan nilai booleanean apakah Cell adalah road
	    */
	  public boolean IsRoad(){
		  return ((code == '-')|| (code == '+') || (code == '='));
	  }
	  /**  Mengembalikan nilai booleanean apakah Cell adalah Park
	    */
	  public boolean IsPark(){
		  return (code == 'P');
	  }
	  /**  Mengembalikan nilai booleanean apakah Cell adalah restaurant
	    */
	  public boolean IsRestaurant(){
		  return (code == 'R');
	  }
	  /**  Mengembalikan nilai booleanean apakah Cell adalah land
	    */
	  public boolean IsLand(){
		  return (code == 'l');
	  }
	  /**  Mengembalikan nilai booleanean apakah Cell adalah water
	    */
	  public boolean IsWater(){
		  return (code == 'w');
	  }
	  /**  Mengembalikan nilai booleanean apakah Cell adalah air
	    */
	  public boolean IsAir(){
		  return (code == 'a');
	  }
	  /**  Mengembalikan nilai kode char dari objek Cell
	    * char ini nantinya yang siap dicetak ke layar
	    */
	  public char render(){
		  return code;
	  }
	  
}
