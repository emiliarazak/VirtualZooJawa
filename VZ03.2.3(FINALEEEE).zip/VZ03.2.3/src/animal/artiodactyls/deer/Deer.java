/**
 * 
 */

package animal.artiodactyls.deer;

import animal.artiodactyls.Artiodactyls;
import renderable.Renderable;

/**Real Class Deer.
 * @author Luthfi Fadillah
 *
 */
public class Deer extends Artiodactyls implements Renderable {
  /** Constructor dari Deer.
   * Menghidupkan hewan Deer.
   *
   * @param x : bertipe int, adalah letak absis Deer yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Deer yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Deer yang dihidupkan.
   */

  public Deer(int bb, int x, int y) {
    super(true,x,y);
    SetBerat(bb);
    setInteraction("Do you know where is santa house??");
  }

  /** Mengembalikan nilai character kode dari objek Deer.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  public char render() {
    return 'D';
  }
}