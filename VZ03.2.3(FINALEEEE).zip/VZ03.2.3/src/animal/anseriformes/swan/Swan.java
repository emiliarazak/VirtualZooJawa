/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animal.anseriformes.swan;
import renderable.Renderable;
import animal.anseriformes.Anseriformes;
/**
*
* @author Emil
*/ 
public class Swan extends Anseriformes implements Renderable {
  /** @brief Constructor dari Swan
      * Menghidupkan hewan Swan
      *
      * @param x integer adalah letak absis Swan yang dihidupkan
      * @param y integer adalah letak ordinat Swan yang dihidupkan
      * @param bb integer adalah berat badan Swan yang dihidupkan
      */
    public Swan(int bb, int x, int y) {
      super(true, x, y);
      SetBerat(bb);
      setInteraction("Qwokk qwokk");
    }
    /** @brief Mengembalikan nilai character kode dari objek Swan
      * Character ini nantinya yang siap dicetak ke layar
      */
    public char render() {
      return 'Q';
    }
}