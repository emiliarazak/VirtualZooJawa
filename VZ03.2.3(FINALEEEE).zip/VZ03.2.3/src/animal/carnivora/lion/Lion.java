/**
 * 
 */

package animal.carnivora.lion;

import animal.carnivora.Carnivora;

/** Kelas spesies Lion.
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Lion extends Carnivora {
  /** Constructor dari Lion.
   * Menghidupkan hewan Lion.
   *
   * @param x integer adalah letak absis Lion yang dihidupkan
   * @param y integer adalah letak ordinat Lion yang dihidupkan
   * @param bb integer adalah berat badan Lion yang dihidupkan
   */
  public Lion(int bb, int x, int y) {
    super(false, x, y);
    SetBerat(bb);
    setInteraction("RoOAORRRR");
  }

  @Override
  /** fungsi Render dari objek Lion
   * Mengembalikan kode Lion pada layar
   * 
   * @return char
   */
  public char render() {
    return 'I';
  }
}
