package zoo;

/**
 * @author aliviaprht
 * @version 3.0
 * @since 24-03-2017
 */

import java.util.Random;

import animal.Animal;
import animal.anseriformes.duck.Duck;
import animal.anseriformes.swan.Swan;
import animal.artiodactyls.deer.Deer;
import animal.artiodactyls.giraffe.Giraffe;
import animal.carnivora.lion.Lion;
import animal.carnivora.meerkat.Meerkat;
import animal.carnivora.wolf.Wolf;
import animal.casuariformes.cassowary.Cassowary;
import animal.cetacea.beluga.Beluga;
import animal.cetacea.dolphin.Dolphin;
import animal.cetacea.orca.Orca;
import animal.primates.gorilla.Gorilla;
import animal.primates.lemur.Lemur;
import animal.primates.monkey.Monkey;
import animal.psittaciformes.cockatoo.Cockatoo;
import animal.psittaciformes.parrot.Parrot;
import animal.selachimorpha.greatwhiteshark.GreatWhiteShark;
import animal.squamata.python.Python;
import animal.strigiformes.owl.Owl;
import animal.squamata.chameleon.Chameleon;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import cage.Cage;
import indices.Indices;
import cell.Cell;
import cell.facility.park.Park;
import cell.facility.restaurant.Restaurant;
import cell.facility.road.Road;
import cell.habitat.airhabitat.AirHabitat;
import cell.habitat.landhabitat.LandHabitat;
import cell.habitat.waterhabitat.WaterHabitat;

public class Zoo {
	//Atribut
	
	/**  Atribut map adalah Matriks of Cell
    */
  private Cell map[][];
  /**  Atribut daftar_kandang adalah Array of Cage yang dimiliki kebun binatang
  */
  private Cage daftar_kandang[];
  /**  Atribut lebar adalah lebar dari kebun binatang
    */
  private int lebar;
  /**  Atribut panjang adalah panjang dari kebun binatang
    */
  private int panjang;
  /**  Atribut banyak_kandang adalah jumlah kandang yang ada di kebun binatang
    */
  private int banyak_kandang;
  /**  Atribut ready_to_print adalah Matriks of character kebun binatang yang siap dicetak ke layar (sudah ada hewan)
    */
  private char ready_to_print[][];
  /**  Atribut base_map adalah Matriks of character kebun binatang hasil render habitat (belum ada hewan)
    */
  private char base_map[][];
  
  //Method
  /** Constructor dari Zoo
    * Menghidupkan kebun binatang
    * @return nothing
   * @throws IOException 
    */
 public Zoo() throws IOException{
	 int input_lebar = 0;
	 int input_panjang = 0;
	 int input_banyak_kandang = 0;
	 int i,j,k;
	 Indices[][] temp_indices;
	 int[] neff_kandang;
	 
	 
	 BufferedReader br = new BufferedReader (new FileReader("src/zoo/map.txt"));
	 
	 String strLine;
	 strLine = br.readLine();
	 for (i=0; i<strLine.length(); i++) {
		 input_lebar = (input_lebar *10) + ((int) strLine.charAt(i) - 48);
	 }
	 
	 strLine = br.readLine();
	 for (i=0; i<strLine.length(); i++) {
		 input_panjang = (input_panjang *10) + ((int) strLine.charAt(i) - 48);
	 }
	 
	 strLine = br.readLine();
	 for (i=0; i<strLine.length(); i++) {
		 input_banyak_kandang = (input_banyak_kandang *10) + ((int) strLine.charAt(i) - 48);
	 }
	 
	 temp_indices = new Indices[input_banyak_kandang][25];
	 for(i=0; i<input_banyak_kandang; i++) {
		 for (j=0; j<25; j++) {
			 temp_indices[i][j] = new Indices();
		 }
	 }
	 
	 lebar = input_lebar;
	 panjang = input_panjang;
	 map = new Cell[lebar][panjang];
	 banyak_kandang = input_banyak_kandang;
	 neff_kandang = new int[banyak_kandang];
	 for (i=0; i<banyak_kandang; i++) {
		 neff_kandang[i] = 0;
	 }
	 
	 char habitat;
	 int code;
	 Indices ind;
	 ind = new Indices(0,0);
	 for (i=0; i<lebar; i++) {
		 strLine = br.readLine();
		 j = 0;
		 k = 0;
		 while (j < input_panjang *2) {
			 ind.SetAbsis(k);
			 ind.SetOrdinat(i);
			 habitat = strLine.charAt(j);
			 if (habitat == 'W') {
	  		     map[i][k] = new WaterHabitat(ind);
			 } 
			 else if (habitat == 'L') {
			     map[i][k] = new LandHabitat(ind);
			 }
			 else if (habitat == 'A') {
			     map[i][k] = new AirHabitat(ind);
			 }
			 else if (habitat == '-') {
			     map[i][k] = new Road(ind, 0);
			 }
			 else if (habitat == '+') {
				 map[i][k] = new Road(ind, 1);
			 }
			 else if (habitat == '=') {
				 map[i][k] = new Road(ind, 2);
			 }
			 else if (habitat == 'P') {
				 map[i][k] = new Park(ind);
			 }
			 else if (habitat == 'R') {
				 map[i][k] = new Restaurant(ind);
			 } 
			 else {

	          }
			 j++; k++;
			 code = ((int) strLine.charAt(j) - 48);
			 if (code != 0) {
				 temp_indices[code-1][neff_kandang[code-1]].CopyIndices(ind);
				 neff_kandang[code-1]++;
			 }
			 j++;
		 }
	 }
	 br.close();
	 
	 daftar_kandang = new Cage[banyak_kandang];
	 /*
	 for (i=0; i<banyak_kandang; i++) {
		 daftar_kandang[i] = new Cage();
	 }
	 */
	 Indices[] temp_indices_input;
	 for (i=0; i < banyak_kandang; i++) {
		 temp_indices_input = new Indices[25];
		 for (j=0; j<25; j++) {
			 temp_indices_input[j] = new Indices();
		 }
		 for (j=0; j < neff_kandang[i]; j++) {
			 temp_indices_input[j].CopyIndices(temp_indices[i][j]);
		 }
		 //Cage C;
		 //C = new Cage(temp_indices_input,neff_kandang[i]);
		 daftar_kandang[i] = new Cage(temp_indices_input,neff_kandang[i]);
	 }
	 
	 base_map = new char[lebar][panjang];
	 ready_to_print = new char[lebar][panjang];
	 for(i=0; i<lebar; i++) {
		 for (j=0; j<panjang; j++) {
			 base_map[i][j] = map[i][j].render();
			 ready_to_print[i][j] = base_map[i][j];
		 }
	 }
	 
	 //Memasukkan Binatang
	 Animal[] animal_input;
   animal_input = new Animal[37];
   i=0;
   //Cage 1
   animal_input[i] = new Beluga(45,2,2);
   daftar_kandang[0].AddAnimal(animal_input[i]);
   animal_input[i] = new Dolphin(45,1,1);
   daftar_kandang[0].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Swan(45,0,0);
   daftar_kandang[0].AddAnimal(animal_input[i]);
   i++;
   //Cage 2
   animal_input[i] = new Cockatoo(10,19,0);
   daftar_kandang[1].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Cockatoo(10,8,2);
   daftar_kandang[1].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Parrot(10,17,0);
   daftar_kandang[1].AddAnimal(animal_input[i]);
   i++;
   //Cage 3
   animal_input[i] = new Lion(100, 1, 4);
   daftar_kandang[2].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Lion(100, 1, 5);
   daftar_kandang[2].AddAnimal(animal_input[i]);
   i++;
   //Cage 4
   animal_input[i] = new Cassowary(70, 6, 4);
   daftar_kandang[3].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Monkey(30, 6, 6);
   daftar_kandang[3].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Deer(60, 7, 5);
   daftar_kandang[3].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Lemur(30,5,7);
   daftar_kandang[3]. AddAnimal(animal_input[i]);
   i++;
   //Cage 5
   animal_input[i] = new Giraffe(100,14,4);
   daftar_kandang[4].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Meerkat(30, 14, 6);
   daftar_kandang[4].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Owl(10, 16, 4);
   daftar_kandang[4].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Chameleon(15, 12, 6);
   daftar_kandang[4].AddAnimal(animal_input[i]);
   i++;
   //Cage 6
   animal_input[i] = new Wolf(70, 18, 8);
   daftar_kandang[5].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Wolf(70, 19, 6);
   daftar_kandang[5].AddAnimal(animal_input[i]);
   i++;
   //Cage 7
   animal_input[i] = new Gorilla(100, 10, 12);
   daftar_kandang[6].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Duck(10, 14, 11);
   daftar_kandang[6].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Swan(10, 12, 12);
   daftar_kandang[6].AddAnimal(animal_input[i]);
   i++;
   //Cage 8
   animal_input[i] = new GreatWhiteShark(150, 5, 19);
   daftar_kandang[7].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new GreatWhiteShark(150, 7, 16);
   daftar_kandang[7].AddAnimal(animal_input[i]);
   i++;
   //Cage 9
   animal_input[i] = new Python(100, 11, 18);
   daftar_kandang[8].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Python(100, 12, 16);
   daftar_kandang[8].AddAnimal(animal_input[i]);
   i++;
   animal_input[i] = new Python(100, 12, 19);
   daftar_kandang[8].AddAnimal(animal_input[i]);
   i++;
   
	 int absis_hewan;
	 int ordinat_hewan;
	 for (i=0; i< banyak_kandang; i++) {
		 for (j=0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
			 absis_hewan = daftar_kandang[i].GetAnimals()[j].GetKoordinat().GetAbsis();
			 ordinat_hewan = daftar_kandang[i].GetAnimals()[j].GetKoordinat().GetOrdinat();
			 ready_to_print[ordinat_hewan][absis_hewan] = daftar_kandang[i].GetAnimals()[j].render();
		 }
	 }
 }
 /** Mengembalikan nilai booleanean apakah hewan dapat tinggal pada Cell C.
  * 
  * @param c Cell yang dicek untuk hewan dapat tinggal atau tidak.
  * @param a Animal yang dicek.
  * @return boolean
  */
 public boolean IsLivable(Animal a, Cell c) {
   if (c.IsHabitat()) {
     return ((c.GetCode() == 'l') && (a.IsLandAnimal())) ||
            ((c.GetCode() == 'w') && (a.IsWaterAnimal())) ||
               ((c.GetCode() == 'a') && (a.IsAirAnimal()));
   } else {
     return false;
   }
 }
 /**  Prosedur Move
   * I.S Semua elemen dalam kebun binatang telah dihidupkan
   * F.S Semua Animals dalam berpindah tempat
   * Menggerakkan hewan yang ada didalam kebun binatang
   * @return nothing
   */
 public void Move(){
	 boolean move;
	 Indices ind;
	 int count, x, y, to, to_x, to_y;
	 Random rand = new Random();
	 ind = new Indices();
	 
	 for (int i = 0; i < banyak_kandang; i++) {
	      for (int j=0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
	        move = false;
	        count = 0;
	        x = (daftar_kandang[i].GetAnimals()[j]).GetKoordinat().GetAbsis();
	        y = (daftar_kandang[i].GetAnimals()[j]).GetKoordinat().GetOrdinat();
	        to = rand.nextInt(4) + 1;
	        while ((!(move)) && (count < 4)){
	          to_x = x; to_y = y;
	          count++;
	          switch (to) {
	            case 1 : {to_x++;}; break;
	            case 2 : {to_y++;}; break;
	            case 3 : {to_x--;}; break; 
	            case 4 : {to_y--;}; break;        
	          }
	          if ((to_y >= 0) && (to_y < lebar) && (to_x >= 0) && (to_x < panjang)) {
		        ind.SetOrdinat(to_y); ind.SetAbsis(to_x);
			    if ((IsLivable(daftar_kandang[i].GetAnimals()[j],map[to_x][to_y])) && 
			    	(daftar_kandang[i].IsHostOf(ind)) && ((ready_to_print[to_y][to_x] == 'w') || (ready_to_print[to_y][to_x] == 'l') || (ready_to_print[to_y][to_x] == 'a'))){
					  move = true;
					  (daftar_kandang[i].GetAnimals()[j]).SetKoordinat(to_x, to_y);
					  ready_to_print[y][x] = base_map[y][x];
					  ready_to_print[to_y][to_x] = (daftar_kandang[i].GetAnimals()[j]).render();
				} 
				else {
				      to = (to % 4) + 1;
				}
			  }
			  else {
			    to = (to % 4) + 1;
			  }
	        }        
	      }
	    } 
 }
 /**  Prosedur Print
   * I.S Zoo telah hidup
   * F.S Semua elemen zoo tercetak pada layar
   * Mencetak kebun binatang beserta seluruh elemennya ke layar
   * @return nothing
   */
 public void Print(){
	 for (int i=0; i<lebar; i++) {
		 for (int j=0; j<panjang; j++) {
			 System.out.print(ready_to_print[i][j]);
			 System.out.print(" ");
		 }
		 System.out.println();
	 }
 }
 /**  Prosedur Hitung Makanan
   * I.S Zoo telah hidup
   * F.S Jumlah makanan yang dibutuhkan kebun binatang setiap harinya tercetak di layar
   * Mengkalkulasikan jumlah makanan yang diperlukan hewan-hewan yang hidup di kebun binatang
   * Mencetak hasil kalkulasi jumlah makanan ke layar
   * @return nothing
   */
 public void HitungMakanan(){
	 int sayur_buah_dan_biji2an = 0;
	 int daging = 0;
	 int i,j;
	 for (i=0; i< banyak_kandang; i++) {
		 for (j=0; j< daftar_kandang[i].GetBanyakHewan(); j++) {
			 if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 0) {
				 sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 100);        
			 }
			 else if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 1) {
		          sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 200);
		          daging = daging + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 200);
		     } 
			 else if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 2) {
		          daging = daging + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 100);
		     }
		 }
	 }
	 
	 System.out.println("Butuh daging sebanyak " + daging + "kg.");
	 System.out.println("Butuh sayur,buah, dan biji-bijian sebanyak " + sayur_buah_dan_biji2an + "kg.");
 }
 /**  Mengembalikan bool apakah indeks tertentu bersinggungan dengan sebuah kandang
   *
   * @param ind adalah indeks yang akan diperiksa
   * @param c adalah kandang yang akan diperiksa
   * @return boolean
   */
 public boolean IsInteractable(Indices ind, Cage c){
	 boolean iya = false;
		Indices it;
		it = new Indices();
		
		it.SetAbsis(ind.GetAbsis()+1); it.SetOrdinat(ind.GetOrdinat());
		iya = (c.IsHostOf(it));
		if (!iya) {
	      it.SetAbsis(ind.GetAbsis()-1); it.SetOrdinat(ind.GetOrdinat());
		  iya = (c.IsHostOf(it));
		}
		if (!iya) {
		  it.SetAbsis(ind.GetAbsis()); it.SetOrdinat(ind.GetOrdinat()+1);
		  iya = (c.IsHostOf(it));
		}
		if (!iya) {
	      it.SetAbsis(ind.GetAbsis()); it.SetOrdinat(ind.GetOrdinat()-1);
		  iya = (c.IsHostOf(it));
		}
		return iya;
 }
 /** Getter daftar kandang pada zoo
   * @return array of cage
   */
 public Cage[] GetKandang(){
	 return daftar_kandang;
 }
 /** Getter ready_to_print pada zoo
   * @return matriks of char 
   */
 public char[][] GetPrint(){
	 return ready_to_print;
 }
 /** Melakukan tour pada zoo
   * I.S Semua elemen pada zoo terdefinisi
   * F.S Melakukan tour di zoo dan berinteraksi pada tiap animal yang dilewati
   * @return nothing
   */
 public void Tour(){
	 Random rand = new Random();
	 boolean jalan;
     Indices[] ent;
	 Indices[] ex;
	 int count_entrance,count_exit;
	 int i,j;
	 int idx_entrance=0;
	 int temp_int = 0;
	 char[][] map;
	 count_entrance = 0;
	 count_exit = 0;
	 map = new char [lebar][panjang];
	    
	    //mindahin map di zoo ke temp map
	    for (i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	          map[i][j] = ready_to_print[i][j];
	      }
	    }
	    
	    //mencari entrance
	    for (i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if (map[i][j] == '+') {
	          count_entrance++;
	        }
	      }
	    }
	    
	    //memasukkan koordinat entrance ke array of Indices
	    ent = new Indices [count_entrance];
	    for (i=0; i<count_entrance; i++) {
	    	ent[i] = new Indices();
	    }
	    
	    for(i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if(map[i][j] == '+') {
	          ent[temp_int].SetAbsis(j);
	          ent[temp_int].SetOrdinat(i);
	          temp_int++;
	        }
	      }
	    }
	    
	    //mencari exit
	    for (i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if (map[i][j] == '=') {
	          count_exit++;
	        }
	      }
	    }
	    temp_int = 0;
	    
	    //memasukkan koordinat exit ke array of Indices
	    ex = new Indices [count_exit];
	    for (i=0; i<count_exit; i++) {
	    	ex[i] = new Indices();
	    }
	    
	    for (i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if(map[i][j] == '=') {
	          ex[temp_int].SetAbsis(j);
	          ex[temp_int].SetOrdinat(i);
	          temp_int++;
	        }
	      }
	    }
	    
	    //menentukan entrance secara acak
	    
	    while (idx_entrance >= (temp_int-1)) {
	      idx_entrance = rand.nextInt(count_entrance) + 1;
	    }
	    
	    // membuat array of visitable
	    boolean[][] IsVisitable;
	    IsVisitable = new boolean [lebar][panjang];
	    for(i = 0; i < lebar; i++) {
	      for(j = 0; j < panjang; j++) {
	        if (map[i][j] == '=' || map[i][j] == '-' || map[i][j] == '+') {
	          IsVisitable[i][j] = true;
	        }
	        else {
	          IsVisitable[i][j] = false;
	        }
	      }
	    }
	    
	    //touring
	    int x = ent[idx_entrance].GetAbsis();
	    int y = ent[idx_entrance].GetOrdinat();
	    System.out.println("Anda baru saja masuk, anda berada di " +  x + "," + y);
	    boolean IsJalanAble[];
	    IsJalanAble = new boolean [4]; // 0 : atas, 1 : kiri, 2 : bawah, 3 : kanan
	    for (i = 0; i < 4; i++) {
	      IsJalanAble[i] = false;
	    }
	    
	    int count_jalan;
	    int n;
	    jalan = true;
	    Indices I;
	    I = new Indices();
	    while (jalan) {
	      System.out.println("Anda berada di " +  x + "," + y);
	      I.SetAbsis(x);
	      I.SetOrdinat(y);
	      for(n = 0; n<banyak_kandang ; n++){
	        if(IsInteractable(I,daftar_kandang[n])){
	          daftar_kandang[n].Inter();
	        }
	      }
	      count_jalan = 0;
	      if ((y>0) && (IsVisitable[y-1][x])) {// di atas bisa jalan?
	        IsJalanAble[0] = true;
	        count_jalan++;
	      } else {
	        IsJalanAble[0] = false;
	      }
	      if((x > 0) && IsVisitable[y][x-1]) {// di kiri bisa jalan?
	        IsJalanAble[1] = true;
	        count_jalan++;
	      } else {
	        IsJalanAble[1] = false;
	      }
	      if ((y < lebar-1) && IsVisitable[y+1][x]) {// di bawah bisa jalan?
	        IsJalanAble[2] = true;
	        count_jalan++;
	      } else {
	        IsJalanAble[2] = false;
	      }
	      if ((x < lebar-1) && IsVisitable[y][x+1]) {// di kanan bisa jalan?
	        IsJalanAble[3] = true;
	        count_jalan++;
	      } else {
	        IsJalanAble[3] = false;
	      }
	      if (count_jalan == 0) {
	        jalan = false;
	      }
	      else {
	        do {
	          n = rand.nextInt(4);
	          System.out.println("u" + n);
	        } while (!IsJalanAble[n]);
	        IsVisitable[y][x] = false;
	        switch (n) {
	          case 0: y--;break;
	          case 1: x--;break;
	          case 2: y++;break;
	          case 3: x++;break;
	          default: jalan=false;
	        }
	      }
	    }
	    //end touring
	    
	    //cek apakah berhenti di exit
	    boolean IsExit = false;
	    for (i = 0; i < count_exit; i++) {
	      if(ex[i].GetAbsis() == x && ex[i].GetOrdinat() == y){
	        IsExit = true;
	      }
	    }
	    if (IsExit) {
	      System.out.println("yeeeyeyeyyey keluar!!!");
	      System.out.println("Anda berada di " +  x + "," + y);
	    }
	    else {
	      System.out.println("noonononono kejebak!!!");
	      System.out.println("Anda berada di " +  x + "," + y);
	    }
	    System.out.println();
 }

}