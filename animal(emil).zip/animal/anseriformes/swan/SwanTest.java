package animal.anseriformes.swan;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SwanTest {
	private Swan q = new Swan(12,1,2);
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}
	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}
	@Test
	public void testInteract() {
		q.Interact();
		assertEquals("Interact() Error!", "Qwokk Qwokk\n", outContent.toString());
	}

	@Test
	public void testSwan() {
		assertEquals("Constructor Swan parameter 1 Error!", 12, q.GetBerat());
		assertEquals("Constructor Swan parameter 2 Error!", 1, q.GetKoordinat().GetAbsis());
		assertEquals("Constructor Swan parameter 3 Error!", 2, q.GetKoordinat().GetOrdinat());
	}

	@Test
	public void testRender() {
		assertEquals("render() Error!", 'Q', q.render());
	}

	@Test
	public void testAnseriformes() {
		assertEquals("Constructor Anseriformes parameter 1 Error!", true, q.IsJinak());
		assertEquals("Constructor Anseriformes parameter 2 Error!", 1, q.GetKoordinat().GetAbsis());
		assertEquals("Constructor Anseriformes parameter 3 Error!", 2, q.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testAnimalIntBooleanBooleanBooleanBooleanIntInt() {
		assertEquals("Constructor Animal parameter 1 Error!", 1, q.GetMakanan());
		assertEquals("Constructor Animal parameter 2 Error!", true, q.IsLandAnimal());
		assertEquals("Constructor Animal parameter 3 Error!", true, q.IsWaterAnimal());
		assertEquals("Constructor Animal parameter 4 Error!", false, q.IsAirAnimal());
		assertEquals("Constructor Animal parameter 5 Error!", true, q.IsJinak());
		assertEquals("Constructor Animal parameter 6 Error!", 1, q.GetKoordinat().GetAbsis());
		assertEquals("Constructor Animal parameter 7 Error!", 2, q.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testGetBerat() {
		assertEquals("GetBerat() Error!", 12, q.GetBerat());
	}
	@Test
	public void testSetBerat() {
		q.SetBerat(13);
		assertEquals("GetBerat() Error!", 13, q.GetBerat());
		q.SetBerat(12);
	}

	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat Absis Error!", 1, q.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat Ordinat Error!", 2, q.GetKoordinat().GetOrdinat());
	}

	@Test
	public void testSetKoordinat() {
		q.SetKoordinat(3, 4);
		assertEquals("GetKoordinat Absis Error!", 3, q.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat Ordinat Error!", 4, q.GetKoordinat().GetOrdinat());
		q.SetKoordinat(1, 2);
	}

	@Test
	public void testIsLandAnimal() {
		assertEquals("IsLandAnimal() Error!", true, q.IsLandAnimal());
	}

	@Test
	public void testIsWaterAnimal() {
		assertEquals("IsWaterAnimal() Error!", true, q.IsWaterAnimal());
	}

	@Test
	public void testIsAirAnimal() {
		assertEquals("IsAirAnimal() Error!", false, q.IsAirAnimal());
	}

	@Test
	public void testIsJinak() {
		assertEquals("IsJinak() Error!", true , q.IsJinak());
	}

	@Test
	public void testGetMakanan() {
		assertEquals("GetMakanan() Error!", 1, q.GetMakanan());
	}
}
