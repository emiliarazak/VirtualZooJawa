package driver;

import java.io.IOException;
import java.util.Scanner;

import zoo.Zoo;

/**
 * 
 */

/**
  * @author Luthfi Fadillah
  * 
  */

public class Driver{
  private Zoo z;
private Scanner key;
  
  /** Constructor untuk Driver.
   */
  public Driver(){
    try {
		z = new Zoo();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
  
  /** Menampilkan MainMenu.
   */
  public void MainMenu(){
    key = new Scanner(System.in);
    int input;
    boolean keluar;
    keluar = false;
    while(!keluar){
      System.out.println("Selamat Datang Di Virtual Zoo");
      System.out.println("");
      System.out.println("Menu: ");
      System.out.println("1. Display Virtual Zoo (Partial)");
      System.out.println("2. Display Virtual Zoo (Full)");
      System.out.println("3. Tour di Virtual Zoo");
      System.out.println("4. Menampilkan Banyak Makanan");
      System.out.println("5. Keluar");
      System.out.println("");
      System.out.print("Input: ");
      input = key.nextInt();
      switch (input){
        case 1 :
          DisplayVirtualZoo(input);
          break;
        case 3 :
          TourVirtualZoo();
          break;
        case 4 :
          DisplayMakanan();
          break;
        case 5 :
          System.out.println("See ya!");
          keluar = true;
          break;
        case 2 :
          DisplayVirtualZoo(input);
          break;
        default :
          System.out.println("Masukan salah");
      }
    }
  }

  /** Menampilkan Virtual Zoo.
   * @param input : bertipe integer, menyatakan input yang dimasukkan user, 1 = Full View, 2 = Partial View
   */
  public void DisplayVirtualZoo(int input){
	key = new Scanner(System.in);
	char n;
    int x1, y1, x2, y2, i, j;
	switch (input){
	  case 1 :
        do{
		  System.out.println("Masukkan koordinat atas-kiri ");
          x1 = key.nextInt();
          y1 = key.nextInt();
          System.out.println("Masukkan koordinat bawah-kanan ");
          x2 = key.nextInt();
          y2 = key.nextInt();
          if ((x1 >= x2) || (y1 >= y2)) {
            System.out.println("Masukan koordinat salah");
          }
        }while((x1 >= x2) || (y1 >= y2));
        
        for (i = x1; i <= x2; i++) {
          for (j = y1; j <= y2; j++) {
            System.out.print(z.GetPrint()[i][j] + " ");
          }
          System.out.println();
        }
        DisplayLegend();
        break;
	  case 2 :
        do {
		  z.Move();
		  z.Print();
		  System.out.println("Move? (y/n) ");
		  n = key.next().charAt(0);
		}while(n == 'y');
        break;
      default :
    	System.out.println("Masukan salah");
    }
  }
  
  /** Melakukan tour pada Virtual Zoo.
    */
  public void TourVirtualZoo(){
    z.Tour();
  }
  
  /** Menampilkan jumlah makanan yang dibutuhkan di kebun binatang dalam satu hari.
    */
  public void DisplayMakanan(){
    z.HitungMakanan();
  }
  
  /** Menampilkan legenda.
    */
  public void DisplayLegend(){
    System.out.println();
    System.out.println("Legend");
    System.out.println("B: Beluga" + "\t" + "S: Big Horn Sheep" + "\t" + "C: Cassowary" + "\t" + "H: Chameleon\t" + "T: Cheetah");
    System.out.println("O: Cockatoo" + "\t" + "D: Deer\t\t\t" + "N: Dolphin" + "\t" + "U: Duck\t\t" + "G: Giraffe");
    System.out.println("J: Gorilla\tK: Great White Shark\tE: Lemur\tI: Lion\t\tM: Meerkat");
    System.out.println("Y: Monkey\t$: Orca\t\t\tZ: Owl\t\tX: Parrots\tV: Python");
    System.out.println("Q: Swan\t\tF: Tarsier\t\t@: Wolf\t\tP: Park\t\tR: Restaurant");
    System.out.println("L: Land Habitat\tW: Water Habitat\tA: Air Habitat\t-: Road\t\t+: Entrance");
    System.out.println("=: Exit");
    System.out.println();  
  }
}
