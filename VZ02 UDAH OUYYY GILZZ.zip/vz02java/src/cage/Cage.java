package cage;

import indices.Indices;
import animal.Animal;

/** Kelas Cell tanpa inheritance
 * 
 * @author alivia
 *
 */

public class Cage {
	//atribut
	/**  Attribut wilayah adalah Array of Indices kandang yang termasuk pada kandang
     */
	Indices[] wilayah;
    /**  Attribut data_animal adalah Array of Animal yang tinggal dikandang tersebut
      */
	Animal[] data_animal;
    /**  Attribut luas menyatakan luasnya kandang
     */
	int luas;
    /**  Attribut banyak_hewan menyatakan jumlah hewan yang hidup di kandang
     */
	int banyak_hewan;
	
	int kapasitas;
	
	//method
	/**  Constructor tanpa parameter dari Cage
     * Menghidupkan kandang
     */
    public Cage(){
    	
    }
    /**  Constructor dengan parameter dari Cage
     * Menghidupkan kandang sesuai dengan input parameter
     *
     * @param I array of Indices menyatakan Cell dengan indices mana saja yang tergabung dalam cage
     * @param Neff integer menyatakan banyaknya Indices yang ada pada array
     */
	public Cage(Indices[] I, int Neff){
		int i;
		wilayah = new Indices[Neff];
		for (i=0; i<Neff; i++) {
			wilayah[i] = new Indices();
			wilayah[i].CopyIndices(I[i]);
		}
		luas = Neff;
		banyak_hewan = 0;
		kapasitas = (Neff*3) / 10;
		data_animal = new Animal [kapasitas];
		for(i=0; i< ((Neff*3) / 10); i++) {
			data_animal[i] = new Animal();
			}
	}
    /**   Mengembalikan nilai booleanean apakah indices termasuk pada cangkupan cage
     *
     * @param I adalah indices yang diperiksa sebagai bagian dari cage
     */
	public boolean IsHostOf(Indices I){
		boolean ketemu = false;
	    int i=0;
	    
	    while ((i<luas) && (!(ketemu))) {
	        ketemu = (I.IsEqual(wilayah[i]));
	        i++;
	    }
	    
	    return ketemu;
	}
    /**  Mengembalikan nilai booleanean apakah masih ada ruang untuk animal di cage tersebut
     */
	public boolean Spacious(){
		return (banyak_hewan < kapasitas);
	}
    /**  Prosedur AddAnimal dari Cage
     * I.S Cage telah hidup dan Masukkan terdefinisi sebagai hewan yang hidup
     * F.S Animal A tercatat pada Data Animals Cage
     * Menambahkan Animals A pada Data Animals Cage
     *
     * @param A adalah Pointer to Animals yang ingin dimasukkan di Data Animals
     */
	public void AddAnimal(Animal A) {
    	Indices I;
    	I = new Indices(A.GetKoordinat().GetAbsis(), A.GetKoordinat().GetOrdinat());
        if (IsHostOf(I)) {
            if (Spacious()) {
                if (!(A.IsJinak())) {
                    if (banyak_hewan == 0) {
                        data_animal[banyak_hewan].CopyAnimal(A); 
                        banyak_hewan++;
                    } else {
                        if (A.GetBerat() == data_animal[0].GetBerat()) {
                            data_animal[banyak_hewan].CopyAnimal(A);
                            banyak_hewan++;
                        }
                    }
                } else {
                    data_animal[banyak_hewan].CopyAnimal(A);
                    banyak_hewan++;
                }
            } else {
                System.out.println("Penuh couyyy");
            }
        }
    }
    /**  Prosedur Inter dari Cage
     * I.S Cage terdefinisi
     * F.S Memanggil semua prosedur interact dari animals yang ada di Cage
     * Mencetak semua suara binatang yang ada dalam kandang
     */
	public void Inter(){
	  for (int i=0; i<banyak_hewan; i++) {
	        data_animal[i].Interact();
	    }

	}
    /**  Mengembalikan nilai atribut DataAnimals
     *
     */
	public Animal[] GetAnimals(){
    	return data_animal;
    }
    /**  GetLuas dari cage
     * Mengembalikan nilai luas suatu kandang
     *
     */
	public int GetLuas(){
    	return luas;
    }
    /**  GetBanyakHewan dari Cage
     * Mengembalikan nilai banyaknya hewan yang ada di suatu kandang
     */
	public int GetBanyakHewan(){
    	return banyak_hewan;
    }
	
	/**  Mengembalikan nilai atribut wilayah
     */
    public Indices[]  GetWilayah(){
      return wilayah;
    }
    /** Prosedur CopyCage
     * I.S Cage C terdefinisi
     * F.S Menyalin Cage C ke current objek
     * 
     * @param C cage yang ingin dicopy ke current objek
     */
    public void CopyCage(Cage C) {
      int i;
      luas = C.luas;
      banyak_hewan = C.banyak_hewan;
      wilayah = new Indices[luas];
      for (i=0; i<luas; i++) {
        wilayah[i] = new Indices();
        wilayah[i].CopyIndices(C.GetWilayah()[i]);
      }
      
      data_animal = new Animal[banyak_hewan];
      for (i=0; i<banyak_hewan; i++) {
        data_animal[i].CopyAnimal(C.GetAnimals()[i]);
      }
    }
    	    
}
