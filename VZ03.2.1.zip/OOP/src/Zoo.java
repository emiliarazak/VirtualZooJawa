import animal.squamata.python.Python;
import indices.*;
/**
 *
 * @author Suzane Ringoringo
 */
public class Zoo {
    /**
     * @param args the command line arguments
     */
  public static void main(String[] args) {
    Python P = new Python(60, 3, 3);
    P.Interact();
    System.out.println(P.GetBerat());
    P.GetKoordinat().PrintKoordinat();
  }
}