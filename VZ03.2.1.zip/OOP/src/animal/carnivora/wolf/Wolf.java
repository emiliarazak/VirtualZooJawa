/**
 * 
 */
package animal.carnivora.wolf;

import animal.carnivora.Carnivora;

/** Kelas spesies Wolf 
 * 
 * @author Suzane Ringoringo
 *
 */
final class Wolf extends Carnivora {
  /** @brief Constructor dari Wolf
   * Menghidupkan hewan Wolf
   *
   * @param x integer adalah letak absis Wolf yang dihidupkan
   * @param y integer adalah letak ordinat Wolf yang dihidupkan
   * @param bb integer adalah berat badan Wolf yang dihidupkan
   */
 public Wolf(int bb, int x, int y) {
   super(false, x, y);
   SetBerat(bb);
 }
 
 @Override
 /** @brief prosedur Interact dari objek Wolf
   * I.S hewan telah dihidupkan
   * F.S interaksi hewan tercetak ke layar
   * Mencetak interaksi Wolf ke layar
   */
 public void Interact() {
   System.out.println("Aaaauuuuuuu");
 }

 @Override
 /** fungsi Render dari objek Wolf
   * Mengembalikan kode Wolf pada layar
   * 
   * @return char
   */
 public char render() {
   return '@';
 }
}
