package animal.carnivora.cheetah;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import animal.carnivora.cheetah.Cheetah;

/** Tes untuk kelas Cheetah
 * 
 * @author suzaneringoringo
 *
 */
public class CheetahTest {
	  
	  public CheetahTest() {
	  }
	  
	  @BeforeClass
	  public static void setUpClass() {
	  }
	  
	  @AfterClass
	  public static void tearDownClass() {
	  }

	  /**
	   * Tes metode Interact pada kelas Cheetah.
	   */
	  @Test
	  public void testInteract() {
	    System.out.println("Interact");
	    Cheetah instance = new Cheetah(70,3,3);
	    instance.Interact();
	  }
	  
	  /**
	   * Tes metode SetBerat dan GetBerat pada kelas Cheetah.
	   */
	  @Test
	  public void testSetGetBerat() {
	    System.out.println("SetBerat dan GetBerat");
	    Cheetah instance = new Cheetah(70,3,3);
	    int gb;
	    gb = instance.GetBerat();
	    assertEquals("Salah berat",gb,70);
	  }
	  
	  /**
	   * Tes metode SetKoordinat dan GetKoordinat pada kelas Cheetah.
	   */
	  @Test
	  public void testSetGetKoordinat() {
	    System.out.println("SetKoordinat dan GetKoordinat");
	    Cheetah instance = new Cheetah(70,1,1);
	    int xresult = 3;
	    int yresult = 3;
	    instance.SetKoordinat(xresult, yresult);
	    assertEquals("Salah x", xresult, instance.GetKoordinat().GetAbsis());
	    assertEquals("Salah y", yresult, instance.GetKoordinat().GetOrdinat());
	  }
	  
	  /**
	   * Tes metode IsLandAnimal, IsWaterAnimal, and IsAirAnimal pada kelas Cheetah.
	   */
	  @Test
	  public void testHabitatAnimal() {
	    System.out.println("IsLandAnimal, IsWaterAnimal, and IsAirAnimal");
	    Cheetah instance = new Cheetah(70,1,1);
	    boolean land = true;
	    boolean water = false;
	    boolean air = false;
	    assertEquals("Salah land", land, instance.IsLandAnimal());
	    assertEquals("Salah water", water, instance.IsWaterAnimal());
	    assertEquals("Salah land", air, instance.IsAirAnimal());
	  }
	  
	  /**
	   * Tes metode IsJinak method pada kelas Cheetah.
	   */
	  @Test
	  public void testIsJinak() {
	    System.out.println("IsJinak");
	    Cheetah instance = new Cheetah(70,1,1);
	    boolean jinak = false;
	    assertEquals("Salah jinak", jinak, instance.IsJinak());
	  }
	  
	  /**
	   * Tes metode IsJinak pada kelas Cheetah.
	   */
	  @Test
	  public void testGetMakanan() {
	    System.out.println("IsJinak");
	    Cheetah instance = new Cheetah(70,1,1);
	    int makan = 2;
	    assertEquals("Salah makan", makan, instance.GetMakanan());
	  }
	  
	  /**
	   * Tes metode Render pada kelas Cheetah.
	   */
	  @Test
	  public void testRender() {
	    System.out.println("Render");
	    Cheetah instance = new Cheetah(70,1,1);
	    char render = 'T';
	    assertEquals("Salah render", render, instance.render());
	  }
	  
}
