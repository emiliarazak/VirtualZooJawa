/**
 * 
 */
package animal.carnivora.cheetah;

import animal.carnivora.Carnivora;
import renderable.Renderable;

/** Kelas spesies Cheetah
 * 
 * @author Suzane Ringoringo
 *
 */
final class Cheetah extends Carnivora implements Renderable {
	/** Constructor dari Cheetah
	 	* Menghidupkan hewan Cheetah
	 	*
	  * @param x integer adalah letak absis Cheetah yang dihidupkan
	  * @param y integer adalah letak ordinat Cheetah yang dihidupkan
	  * @param bb integer adalah berat badan Cheetah yang dihidupkan
	  */
	public Cheetah(int bb, int x, int y) {
		super(false, x, y);
		SetBerat(bb);
	}
	  
	@Override
	/** prosedur Interact dari objek Cheetah
	 	* I.S hewan telah dihidupkan
	 	* F.S interaksi hewan tercetak ke layar
	 	* Mencetak interaksi Cheetah ke layar
	 	*/
	public void Interact() {
		System.out.println("*runs so swiftly*");
	}

	@Override
  /** fungsi Render dari objek Cheetah
    * Mengembalikan kode Cheetah pada layar
    * 
    * @return char
    */
	public char render() {
		return 'T';
	}
}
