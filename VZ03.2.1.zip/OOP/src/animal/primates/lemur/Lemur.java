/**
 * 
 */
package animal.primates.lemur;

import animal.primates.Primates;
import renderable.Renderable;

/** Kelas spesies Lemur
 * 
 * @author Suzane Ringoringo
 *
 */
final class Lemur extends Primates implements Renderable {
  /** @brief Constructor dari Lemur
   * Menghidupkan hewan Lemur
   *
   * @param x integer adalah letak absis Lemur yang dihidupkan
   * @param y integer adalah letak ordinat Lemur yang dihidupkan
   * @param bb integer adalah berat badan Lemur yang dihidupkan
   */
  public Lemur(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
  }
 
  @Override
  /** @brief prosedur Interact dari objek Lemur
   * I.S hewan telah dihidupkan
   * F.S interaksi hewan tercetak ke layar
   * Mencetak interaksi Lemur ke layar
   */
  public void Interact() {
    System.out.println("*chirps*");
  }
  
  @Override
  /** fungsi Render dari objek Lemur
    * Mengembalikan kode Lemur pada layar
    * 
    * @return char
    */
  public char render() {
    return 'E';
  }
}
