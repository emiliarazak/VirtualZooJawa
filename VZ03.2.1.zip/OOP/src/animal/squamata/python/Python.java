/**
 * 
 */
package animal.squamata.python;

import animal.squamata.Squamata;

/** Kelas spesies Python
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Python extends Squamata {
  /** Constructor dari Python
   * Menghidupkan hewan Python
   *
   * @param x integer adalah letak absis Python yang dihidupkan
   * @param y integer adalah letak ordinat Python yang dihidupkan
   * @param bb integer adalah berat badan Python yang dihidupkan
   */
  public Python(int bb, int x, int y) {
    super(false, x, y);
    SetBerat(bb);
  }
    
  @Override
  /** prosedur Interact dari objek Python
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Python ke layar
    */
  public void Interact() {
    System.out.println("Sssshhh");
  }

  @Override
  /** fungsi Render dari objek Python
    * Mengembalikan kode Python pada layar
    * 
    * @return char
    */
  public char render() {
    return 'V';
  }
  
  
}
