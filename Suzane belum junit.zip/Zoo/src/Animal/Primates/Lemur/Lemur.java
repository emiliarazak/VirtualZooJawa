/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animal.Primates.Lemur;

import Animal.Primates.Primates;

/**
 *
 * @author User
 */
public class Lemur extends Primates {
  /** @brief Constructor dari Lemur
    * Menghidupkan hewan Lemur
    *
    * @param x integer adalah letak absis Lemur yang dihidupkan
    * @param y integer adalah letak ordinat Lemur yang dihidupkan
    * @param bb integer adalah berat badan Lemur yang dihidupkan
    */
  public Lemur(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
  }
  
  @Override
  /** @brief prosedur Interact dari objek Lemur
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Lemur ke layar
    */
  public void Interact() {
    System.out.println("*chirps*");
  }
}