/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animal.Primates.Gorilla;

import Animal.Primates.Primates;

/**
 *
 * @author User
 */
public class Gorilla extends Primates {
  /** @brief Constructor dari Gorilla
    * Menghidupkan hewan Gorilla
    *
    * @param x integer adalah letak absis Gorilla yang dihidupkan
    * @param y integer adalah letak ordinat Gorilla yang dihidupkan
    * @param bb integer adalah berat badan Gorilla yang dihidupkan
    */
  public Gorilla(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
  }
  
  @Override
  /** @brief prosedur Interact dari objek Gorilla
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Gorilla ke layar
    */
  public void Interact() {
    System.out.println("UUUAAAA");
  }
}