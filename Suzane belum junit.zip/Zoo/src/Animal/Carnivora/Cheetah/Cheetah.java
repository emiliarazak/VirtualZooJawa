/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animal.Carnivora.Cheetah;

import Animal.Carnivora.Carnivora;

/**
 *
 * @author User
 */
public class Cheetah extends Carnivora {
  /** @brief Constructor dari Cheetah
    * Menghidupkan hewan Cheetah
    *
    * @param x integer adalah letak absis Cheetah yang dihidupkan
    * @param y integer adalah letak ordinat Cheetah yang dihidupkan
    * @param bb integer adalah berat badan Cheetah yang dihidupkan
    */
  public Cheetah(int bb, int x, int y) {
    super(false, x, y);
    SetBerat(bb);
  }
  
  @Override
  /** @brief prosedur Interact dari objek Cheetah
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Cheetah ke layar
    */
  public void Interact() {
    System.out.println("*runs so swiftly*");
  }
}