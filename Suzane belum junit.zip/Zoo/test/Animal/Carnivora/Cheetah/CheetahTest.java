/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animal.Carnivora.Cheetah;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class CheetahTest {
  
  public CheetahTest() {
  }
  
  @BeforeClass
  public static void setUpClass() {
  }
  
  @AfterClass
  public static void tearDownClass() {
  }

  /**
   * Test of Interact method, of class Cheetah.
   */
  @Test
  public void testInteract() {
    System.out.println("Interact");
    Cheetah instance = new Cheetah(70,3,3);
    instance.Interact();
    // TODO review the generated test code and remove the default call to fail.
    fail("The test case is a prototype.");
  }
  
  /**
   * Test of GetBerat method, of class Animal.
   */
  @Test
  public void testGetBerat() {
    System.out.println("GetBerat");
    Cheetah instance = new Cheetah(70,3,3);
    int gb;
    gb = instance.GetBerat();
    System.out.println(gb + "=" + 70);
    assertEquals("Salah",gb,70);
    // TODO review the generated test code and remove the default call to fail.
    fail("The test case is a prototype.");
  }
  
}
