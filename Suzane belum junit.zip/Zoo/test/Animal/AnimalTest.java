/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animal;

import Indices.Indices;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class AnimalTest {
  
  public AnimalTest() {
  }
  
  @BeforeClass
  public static void setUpClass() {
  }
  
  @AfterClass
  public static void tearDownClass() {
  }

  /**
   * Test of GetBerat and SetBerat method, of class Animal.
   */
  @Test
  public void testSetGetBerat() {
    System.out.println("SetBerat and GetBerat");
    Animal instance = new AnimalImpl();
    instance.SetBerat(70);
    int expResult = 70;
    int result = instance.GetBerat();
    assertEquals(expResult, result);
  }

  /**
   * Test of IsLandAnimal method, of class Animal.
   */
  @Test
  public void testIsLandAnimal() {
    System.out.println("IsLandAnimal");
    Animal instance = new AnimalImpl();
    boolean expResult = false;
    boolean result = instance.IsLandAnimal();
    assertEquals(expResult, result);
  }

  /**
   * Test of IsWaterAnimal method, of class Animal.
   */
  @Test
  public void testIsWaterAnimal() {
    System.out.println("IsWaterAnimal");
    Animal instance = new AnimalImpl();
    boolean expResult = false;
    boolean result = instance.IsWaterAnimal();
    assertEquals(expResult, result);
  }

  /**
   * Test of IsAirAnimal method, of class Animal.
   */
  @Test
  public void testIsAirAnimal() {
    System.out.println("IsAirAnimal");
    Animal instance = new AnimalImpl();
    boolean expResult = false;
    boolean result = instance.IsAirAnimal();
    assertEquals(expResult, result);
  }

  /**
   * Test of IsJinak method, of class Animal.
   */
  @Test
  public void testIsJinak() {
    System.out.println("IsJinak");
    Animal instance = new AnimalImpl();
    boolean expResult = false;
    boolean result = instance.IsJinak();
    assertEquals(expResult, result);
  }

  /**
   * Test of GetMakanan method, of class Animal.
   */
  @Test
  public void testGetMakanan() {
    System.out.println("GetMakanan");
    Animal instance = new AnimalImpl();
    int expResult = 0;
    int result = instance.GetMakanan();
    assertEquals(expResult, result);
  }

  public class AnimalImpl extends Animal {

    @Override
    public void Interact() {
    }
  }
  
}
