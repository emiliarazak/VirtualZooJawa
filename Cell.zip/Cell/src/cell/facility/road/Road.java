/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cell.facility.road;
import cell.facility.Facility;
import indices.Indices;
/**
*
* @author Emil
*/
public class Road extends Facility {
	/** @brief Atribut jenis Road
	    */
	    private int rtype;
		/** @brief Constructor dari Road
	    * Menghidupkan fasilitas jalan
	    *
	    * @param I Indices adalah alamat di mana fasilitas dihidupkan
	    */
	    public Road(Indices ind, int rtype){
	    	super(ind, 0, 's');
	    	this.rtype=rtype;
	    }
	    @Override
	     /** @brief Mengembalikan nilai character kode dari objek Road
	    * Character ini nantinya yang siap di Print ke layar
	    */
	     public char render() {
	    	char c = 0;
	     if (rtype == 0) {
	      c='-';
	      }
	     else if (rtype == 1) {
	      c='+';
	     }
	     else if (rtype == 2) {
	       c='=';
	     }
		return c;
	    }
}
