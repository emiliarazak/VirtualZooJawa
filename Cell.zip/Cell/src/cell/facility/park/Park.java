/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cell.facility.park;
import cell.facility.Facility;
import indices.Indices;
/**
*
* @author Emil
*/
public class Park extends Facility {
	 /** @brief Constructor dari Park
	    * Menghidupkan fasilitas taman
	    *
	    * @param I Indices adalah alamat dimana fasilitas dihidupkan
	    */	
		public Park(Indices ind) {
			super(ind, 1, 'p');
		}
		@Override
		/** @brief Mengembalikan nilai character kode dari objek Park
	  	* Character ini nantinya yang siap dicetak ke layar
	  	*/
	  	public char render() {
	  		return 'P';
	  	}
}
