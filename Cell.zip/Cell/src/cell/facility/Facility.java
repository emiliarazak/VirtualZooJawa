/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cell.facility;

import cell.Cell;
import indices.Indices;

/**
*
* @author Emil
*/
public abstract class Facility extends Cell {
	/** @brief Attribut Ftype yang adalah type dari fasilitas
	    */
		protected int fType;
		/** @brief Constructor dari Facility
	    * Menghidupkan fasilitas
	    *
	    * @param I Indices adalah alamat dimana fasilitas dihidupkan
	    * @param type integer adalah kode dari fasilitas dimana 0=Road, 1=Park, 2=Restaurant
	    * @param code character adalah suatu huruf untuk merepresentasikan fasilitas di layar.
	    */
		public Facility(Indices ind, int type, char code) {
		 	super(ind, 1, code);
		 	fType=type;
		}
		 /** @brief Mengembalikan nilai boolean apakah fasilitas adalah road
	    */
		public final boolean IsRoad() {
			return (fType==0);
		}
		/** @brief Mengembalikan nilai boolean apakah fasilitas adalah park
	    */
	    public final boolean IsPark() {
	    	return (fType==1);
	    }
	     /** @brief Mengembalikan nilai boolean apakah fasilitas adalah restaurant
	    */
	    public final boolean IsRestaurant(){
	    	return (fType==2);
	    }
}
