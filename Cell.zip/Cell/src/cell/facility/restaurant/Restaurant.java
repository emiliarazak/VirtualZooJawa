/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cell.facility.restaurant;
import cell.facility.Facility;
import indices.Indices;

/**
*
* @author Emil
*/
public class Restaurant extends Facility {
	/** @brief Constructor dari Restaurant
	    * Menghidupkan fasilitas restauran
	    *
	    * @param I Indices adalah alamat dimana fasilitas dihidupkan
	    */
	    public Restaurant(Indices ind) {
	    	super(ind, 2, 'r');
	    }
	     /** @brief Mengembalikan nilai character kode dari objek Restaurant
	    * Character ini nantinya yang siap di Print ke layar
	    */
	     public char render() {
	     	return 'R';
	     }
}
