package cell.habitat.landhabitat;
import static org.junit.Assert.*;
import org.junit.Test;
import indices.Indices;
/**
*
* @author Emil
*/
public class LandHabitatTest {
	private Indices ind = new Indices(3,6);
	private LandHabitat l = new LandHabitat(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'l', l.render());
	}
	@Test
	public void testLandHabitat() {
		assertEquals("Constructor LandHabitat parameter 1 Error!", 3, l.GetKoordinat().GetAbsis());
		assertEquals("Constructor LandHabitat parameter 1 Error!", 6, l.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testHabitat() {
		assertEquals("Constructor Habitat parameter 1 Error!", 3, l.GetKoordinat().GetAbsis());
		assertEquals("Constructor Habitat parameter 1 Error!", 6, l.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Habitat parameter 2 Error!", true, l.IsLand());
		assertEquals("Constructor Habitat parameter 2 Error!", false, l.IsWater());
		assertEquals("Constructor Habitat parameter 2 Error!", false, l.IsAir());
		assertEquals("Constructor Habitat parameter 3 Error!", 'l', l.GetCode());
	}
	@Test
	public void testIsLand() {
		assertEquals("IsLand() Error!", true, l.IsLand());
	}
	@Test
	public void testIsWater() {
		assertEquals("IsWater() Error!", false, l.IsWater());
	}
	@Test
	public void testIsAir() {
		assertEquals("IsAir() Error!", false, l.IsAir());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 3, l.GetKoordinat().GetAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 6, l.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, l.IsHabitat());
		assertEquals("Constructor Cell parameter 2 Error!", false, l.IsFacility());
		assertEquals("Constructor Cell parameter 3 Error!", 'l', l.GetCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat() Error!", 3, l.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat() Error!", 6, l.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("IsHabitat() Error!", true, l.IsHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("IsFacility() Error!", false, l.IsFacility());
	}

	@Test
	public void testGetCode() {
		assertEquals("GetCode() Error!", 'l', l.GetCode());
	}
}
