package cell.habitat.waterhabitat;
import static org.junit.Assert.*;

import org.junit.Test;

import indices.Indices;
/**
*
* @author Emil
*/
public class WaterHabitatTest {
	private Indices ind = new Indices(2,5);
	private WaterHabitat w = new WaterHabitat(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'w', w.render());
	}
	@Test
	public void testWaterHabitat() {
		assertEquals("Constructor WaterHabitat parameter 1 Error!", 2, w.GetKoordinat().GetAbsis());
		assertEquals("Constructor WaterHabitat parameter 1 Error!", 5, w.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testHabitat() {
		assertEquals("Constructor Habitat parameter 1 Error!", 2, w.GetKoordinat().GetAbsis());
		assertEquals("Constructor Habitat parameter 1 Error!", 5, w.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Habitat parameter 2 Error!", true, w.IsWater());
		assertEquals("Constructor Habitat parameter 2 Error!", false, w.IsLand());
		assertEquals("Constructor Habitat parameter 2 Error!", false, w.IsAir());
		assertEquals("Constructor Habitat parameter 2 Error!", 'w', w.GetCode());
	}
	@Test
	public void testIsLand() {
		assertEquals("IsLand() Error!", false, w.IsLand());
	}
	@Test
	public void testIsWater() {
		assertEquals("IsWater() Error!", true, w.IsWater());
	}
	@Test
	public void testIsAir() {
		assertEquals("IsAir() Error!", false, w.IsAir());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 2, w.GetKoordinat().GetAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 5, w.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, w.IsHabitat());
		assertEquals("Constructor Cell parameter 2 Error!", false, w.IsFacility());
		assertEquals("Constructor Cell parameter 3 Error!", 'w', w.GetCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat() Error!", 2, w.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat() Error!", 5, w.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("IsHabitat() Error!", true, w.IsHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("IsFacility() Error!", false, w.IsFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("GetCode() Error!", 'w', w.GetCode());
	}
}
