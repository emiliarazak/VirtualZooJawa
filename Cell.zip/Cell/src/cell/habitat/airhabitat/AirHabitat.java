/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cell.habitat.airhabitat;
import cell.habitat.Habitat;
import indices.Indices;
/**
*
* @author Emil
*/
public class AirHabitat extends Habitat {
	 /** @brief Constructor dari Air Habitat
	    * Menghidupkan habitat udara
	    *
	    * @param I Indices adalah alamat dimana habitat dihidupkan
	    */
		 public AirHabitat(Indices ind){
		 	super(ind, 2, 'a');
		 }
		 /** @brief Mengembalikan nilai character kode dari objek Air Habitat
	    * Character ini nantinya yang siap di Print ke layar
	    */
		 public char render() {
		 	return 'a';
		 }
}
