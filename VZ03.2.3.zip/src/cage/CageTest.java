/**
 * 
 */
package cage;

import static org.junit.Assert.*;

import org.junit.Test;
import indices.Indices;
import animal.Animal;
import animal.carnivora.cheetah.*;

/** Tes untuk kelas cage.
 * 
 * @author Alivia Dewi Parahita
 *
 */
public class CageTest {

  /**
   * Tes metode Constuctor kelas cage .
   */
  @Test
  public void testCageIndicesArrayInt() {
    System.out.println("Constructor");
    
  }

  /**
   * Tes metode CopyCage.
   */
  @Test
  public void testCopyCage() {
    System.out.println("CopyCage");

  }

  /**
   * Tes metode untuk IsHostOf.
   */
  @Test
  public void testIsHostOf() {
    int i;
    System.out.println("IsHostOf");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    Indices test;
    test = new Indices(4,5);
    
    assertEquals("Salah IsHostOf", false, instance.IsHostOf(test));
    
  }

  /**
   * Tes metode untuk spacious.
   */
  @Test
  public void testSpacious() {
    int i;
    System.out.println("Spacious");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    assertEquals("Salah spacious", true, instance.Spacious());
  }

  /**
   * Tes metode untuk AddAnimal.
   */
  @Test
  public void testAddAnimal() {
    int i;
    System.out.println("AddAnimal");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    Cheetah test = new Cheetah(70,0,0);
    instance.AddAnimal(test);
    System.out.println(instance.GetAnimals()[0].render());
    instance.GetAnimals()[0].Interact();
    assertEquals("Salah addAnimals", 1, instance.GetBanyakHewan());
  }

  /**
   * Tes metod inter.
   * 
   */
  @Test
  public void testInter() {
    System.out.println("Inter");
    
  }

  /**
   * Tes metode untuk IsCageOf.
   */
  @Test
  public void testIsCageOf() {
    int i;
    System.out.println("IsCageOf");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].SetAbsis(0); ind[0].SetOrdinat(1);
    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    Cheetah test1 = new Cheetah(70,0,1);
    Cheetah test2 = new Cheetah(70,3,4);
    instance.AddAnimal(test1);
    
    assertEquals("Salah IsCageOf test 1", true, instance.IsCageOf(test1));
    assertEquals("Salah IsCageOf test 2", false, instance.IsCageOf(test2));
  }

  /**
   * Tes metode GetAnimals.
   */
  @Test
  public void testGetAnimals() {
    int i;
    System.out.println("GetAnimal");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    Cheetah test = new Cheetah(70,0,0);
    instance.AddAnimal(test);
    
    assertEquals("Salah GetAnimal test render", test.render(), instance.GetAnimals()[0].render());
    assertEquals("Salah GetAnimal test berat", test.GetBerat(), instance.GetAnimals()[0].GetBerat());
     
  }

  /**
   * Tes metode GetWilayah pada kelas cage.
   */
  @Test
  public void testGetWilayah() {
    int i;
    System.out.println("GetWilayah");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    assertEquals("Salah wilayah 1 absis", 0, instance.GetWilayah()[0].GetAbsis());
    assertEquals("Salah wilayah 1 ordinat", 0, instance.GetWilayah()[0].GetOrdinat());
    assertEquals("Salah wilayah 2 absis", 0, instance.GetWilayah()[1].GetAbsis());
    assertEquals("Salah wilayah 2 ordinat", 1, instance.GetWilayah()[1].GetOrdinat());
    assertEquals("Salah wilayah 3 absis", 1, instance.GetWilayah()[2].GetAbsis());
    assertEquals("Salah wilayah 3 ordinat", 0, instance.GetWilayah()[2].GetOrdinat());
    assertEquals("Salah wilayah 4 absis", 1, instance.GetWilayah()[3].GetAbsis());
    assertEquals("Salah wilayah 4 ordinat", 1, instance.GetWilayah()[3].GetOrdinat());
    
  }

  /**
   * Tes metode GetLuas pada kelas cage.
   */
  @Test
  public void testGetLuas() {
    int i;
    System.out.println("GetLuas");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    assertEquals("Salah luas", 4, instance.GetLuas());
  }

  /**
   * Tes metode GetBanyakHewan pada kelas cage.
   */
  @Test
  public void testGetBanyakHewan() {
    int i;
    System.out.println("GetBanyakHewan");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].SetAbsis(0); ind[0].SetOrdinat(0);
    ind[1].SetAbsis(0); ind[1].SetOrdinat(1);
    ind[2].SetAbsis(1); ind[2].SetOrdinat(0);
    ind[3].SetAbsis(1); ind[3].SetOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    assertEquals("Salah banyak_hewan", 0, instance.GetBanyakHewan());
  }

}
