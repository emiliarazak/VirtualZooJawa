/**
 * 
 */
package animal.primates.lemur;

import animal.primates.Primates;

/** Kelas spesies Lemur
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Lemur extends Primates {
  /** @brief Constructor dari Lemur
   * Menghidupkan hewan Lemur
   *
   * @param x integer adalah letak absis Lemur yang dihidupkan
   * @param y integer adalah letak ordinat Lemur yang dihidupkan
   * @param bb integer adalah berat badan Lemur yang dihidupkan
   */
  public Lemur(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
    setInteraction("*chirps*");
  }
  
  @Override
  /** fungsi Render dari objek Lemur
    * Mengembalikan kode Lemur pada layar
    * 
    * @return char
    */
  public char render() {
    return 'E';
  }
}
