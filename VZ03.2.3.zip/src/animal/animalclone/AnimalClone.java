/**
 * 
 */
package animal.animalclone;

import animal.Animal;

/**
 * @author Suzane Ringoringo
 *
 */
public final class AnimalClone extends Animal {

  /**
   *
   */
  char copy_render;
  
  public AnimalClone(char source_render, String source_interact) {
    super(0,false,false,false,true,0,0);
    copy_render = source_render;
    setInteraction(source_interact);
  }
  
  public char render() {
    return copy_render;
  }

}
