package animal.anseriformes.duck;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
*
* @author Emil
*/ 
public class DuckTest {
	private Duck u = new Duck(3,1,2);
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}
	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}
	@Test
	public void testInteract() {
		u.Interact();
		assertEquals("Interact() Error!", "Qwekk Qwekk\n", outContent.toString());
	}
	@Test
	public void testDuck() {
		assertEquals("Constructor Duck parameter 1 Error!", 3, u.GetBerat());
		assertEquals("Constructor Duck parameter 2 Error!", 1, u.GetKoordinat().GetAbsis());
		assertEquals("Constructor Duck parameter 3 Error!", 2, u.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'U', u.render());
	}

	@Test
	public void testAnseriformes() {
		assertEquals("Constructor Anseriformes parameter 1 Error!", true, u.IsJinak());
		assertEquals("Constructor Anseriformes parameter 2 Error!", 1, u.GetKoordinat().GetAbsis());
		assertEquals("Constructor Anseriformes parameter 3 Error!", 2, u.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testAnimalIntBooleanBooleanBooleanBooleanIntInt() {
		assertEquals("Constructor Animal parameter 1 Error!", 1, u.GetMakanan());
		assertEquals("Constructor Animal parameter 2 Error!", true, u.IsLandAnimal());
		assertEquals("Constructor Animal parameter 3 Error!", true, u.IsWaterAnimal());
		assertEquals("Constructor Animal parameter 4 Error!", false, u.IsAirAnimal());
		assertEquals("Constructor Animal parameter 5 Error!", true, u.IsJinak());
		assertEquals("Constructor Animal parameter 6 Error!", 1, u.GetKoordinat().GetAbsis());
		assertEquals("Constructor Animal parameter 7 Error!", 2, u.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testGetBerat() {
		assertEquals("GetBerat() Error!", 3, u.GetBerat());
	}
	@Test
	public void testSetBerat() {
		u.SetBerat(2);
		assertEquals("SetBerat() Error!", 2, u.GetBerat());
		u.SetBerat(3);
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat Absis Error!", 1, u.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat Ordinat Error!", 2, u.GetKoordinat().GetOrdinat());
	}

	@Test
	public void testSetKoordinat() {
		u.SetKoordinat(3, 4);
		assertEquals("GetKoordinat Absis Error!", 3, u.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat Ordinat Error!", 4, u.GetKoordinat().GetOrdinat());
		u.SetKoordinat(1, 2);
	}

	@Test
	public void testIsLandAnimal() {
		assertEquals("IsLandAnimal() Error!", true, u.IsLandAnimal());
	}

	@Test
	public void testIsWaterAnimal() {
		assertEquals("IsWaterAnimal() Error!", true, u.IsWaterAnimal());
	}

	@Test
	public void testIsAirAnimal() {
		assertEquals("IsAirAnimal() Error!", false, u.IsAirAnimal());
	}
	@Test
	public void testIsJinak() {
		assertEquals("IsJinak() Error!", true , u.IsJinak());
	}

	@Test
	public void testGetMakanan() {
		assertEquals("GetMakanan() Error!", 1, u.GetMakanan());
	}
}