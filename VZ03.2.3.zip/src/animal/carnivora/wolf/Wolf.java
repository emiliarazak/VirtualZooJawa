/**
 * 
 */

package animal.carnivora.wolf;

import animal.carnivora.Carnivora;

/** Kelas spesies Wolf.
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Wolf extends Carnivora {
  /** Constructor dari Wolf.
   * Menghidupkan hewan Wolf.
   *
   * @param x integer adalah letak absis Wolf yang dihidupkan
   * @param y integer adalah letak ordinat Wolf yang dihidupkan
   * @param bb integer adalah berat badan Wolf yang dihidupkan
   */
  
  public Wolf(int bb, int x, int y) {
    super(false, x, y);
    SetBerat(bb);
    setInteraction("Aaaauuuuuuu");
  }

  @Override
  /** fungsi Render dari objek Wolf
   * Mengembalikan kode Wolf pada layar
   * 
   * @return char
   */
  
  public char render() {
    return '@';
  }
}
