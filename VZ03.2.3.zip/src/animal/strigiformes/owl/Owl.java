/**
 * 
 */

package animal.strigiformes.owl;

import animal.strigiformes.Strigiformes;
import renderable.Renderable;

/**Real Class Owl.
 * @author Alivia Dewi Parahita
 *
 */

public class Owl extends Strigiformes implements Renderable {
  /** Constructor dari Owl.
   * Menghidupkan hewan Owl.
   *
   * @param x : bertipe int, adalah letak absis Owl yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Owl yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Owl yang dihidupkan.
   */
  
  public Owl(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
    setInteraction("Coccooo Coccooo");
  }
  
  /** Mengembalikan nilai character kode dari objek Owl.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  
  public char render() {
    return 'Z';
  }
}