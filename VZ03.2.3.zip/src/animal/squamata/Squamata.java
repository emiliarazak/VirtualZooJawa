/**
 * 
 */

package animal.squamata;

import animal.Animal;

/** Kelas ordo Squamata.
 * 
 * @author Suzane Ringoringo
 *
 */
public abstract class Squamata extends Animal {
  /** Constructor dari Squamata.
   * Menghidupkan hewan Ordo Squamata.
   *
   * @param x integer adalah letak absis Squamata yang dihidupkan
   * @param y integer adalah letak ordinat Squamata yang dihidupkan
   * @param kejinakan boolean menyatakan jinak tidaknya hewan
   */
  
  public Squamata(boolean kejinakan, int x, int y) {
    super(2, true, false, false,kejinakan,x,y);
  }
}
