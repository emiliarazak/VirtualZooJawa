package zoo;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import zoo.Zoo;

public class ZooTest {

  @Test
  public void testZoo() {
    Zoo instance;
    try {
      instance = new Zoo();
      instance.Print();
      instance.Move();
      System.out.println();
      System.out.println();
      instance.Print();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

}
