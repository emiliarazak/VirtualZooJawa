package cell.habitat.airhabitat;
import static org.junit.Assert.*;
import org.junit.Test;

import indices.Indices;
/**
*
* @author Emil
*/
public class AirHabitatTest {
	private Indices ind = new Indices(2,4);
	private AirHabitat a = new AirHabitat(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'a', a.render());
	}
	@Test
	public void testAirHabitat() {
		assertEquals("Constructor AirHabitat parameter 1 Error!", 2, a.GetKoordinat().GetAbsis());
		assertEquals("Constructor AirHabitat parameter 1 Error!", 4, a.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testHabitat() {
		assertEquals("Constructor Habitat parameter 1 Error!", 2, a.GetKoordinat().GetAbsis());
		assertEquals("Constructor Habitat parameter 1 Error!", 4, a.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Habitat parameter 2 Error!", true, a.IsAir());
		assertEquals("Constructor Habitat parameter 2 Error!", false, a.IsLand());
		assertEquals("Constructor Habitat parameter 2 Error!", false, a.IsWater());
		assertEquals("Constructor Habitat parameter 3 Error!", 'a', a.GetCode());
	}
	@Test
	public void testIsLand() {
		assertEquals("IsLand() Error!", false, a.IsLand());
	}
	@Test
	public void testIsWater() {
		assertEquals("IsWater() Error!", false, a.IsWater());
	}
	@Test
	public void testIsAir() {
		assertEquals("IsAir() Error!", true, a.IsAir());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 2, a.GetKoordinat().GetAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 4, a.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, a.IsHabitat());
		assertEquals("Constructor Cell parameter 2 Error!", false, a.IsFacility());
		assertEquals("Constructor Cell parameter 3 Error!", 'a', a.GetCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat() Error!", 2, a.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat() Error!", 4, a.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("IsHabitat() Error!", true, a.IsHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("IsFacility() Error!", false, a.IsFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("GetCode() Error!", 'a', a.GetCode());
	}
}