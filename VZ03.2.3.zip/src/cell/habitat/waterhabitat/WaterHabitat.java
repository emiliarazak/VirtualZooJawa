/*
 * To change this license header, choose License Headers in Project Properties.*/
package cell.habitat.waterhabitat;
import cell.habitat.Habitat;
import indices.Indices;

/**
*
* @author Emil
*/
public class WaterHabitat extends Habitat {
  /** @brief Constructor dari Water Habitat
      * Menghidupkan habitat air
      *
      * @param I Indices adalah alamat dimana habitat dihidupkan
      */
      public WaterHabitat(Indices ind) {
        super(ind, 1, 'w');
      }
      /** @brief Mengembalikan nilai character kode dari objek Water Habitat
      * Character ini nantinya yang siap dicetak ke layar
      */
      public char render() {
        return 'w';
      }
}