/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cell;

import renderable.*;
import indices.*;
/**
 *
 * @author Emil
 */

public abstract class Cell implements Renderable {
    /** @brief Attribut Koordinat yang adalah Indices letak cell
    */
     protected Indices koordinat;
     /** @brief Attribut type yang adalah type dari Cell
    */
     protected int type;
     /** @brief Attribut code yang adalah code dari Cell
    */
     protected char code;
   /** @brief Constructor dari Cell
    * Menghidupkan cell
    *
    * @param I Indices adalah alamat dimana cell dihidupkan
    * @param Type integer adalah kode dari cell dimana 0=Habitat, 1=Facility
    * @param Code character adalah suatu huruf untuk merepresentasikan cell di layar.
    */
  public Cell(Indices ind, int t, char c){
    koordinat=ind;
    type=t;
    code=c;
   }
  @Override
   /** @brief Mengembalikan nilai character render dari objek Cell
    * Character ini nantinya yang siap di Print ke layar
    */
  public char render () {
    return '.';
   }
   /** @brief Mengembalikan nilai Indices dimana cell berada
    */
  public Indices GetKoordinat() {
      return koordinat;
    }
    /** @brief Mengembalikan nilai boolean apakah cell adalah habitat
    */
    public final boolean IsHabitat() {
      return (type==0);
    }
    /** @brief Mengembalikan nilai boolean apakah cell adalah fasilitas
    */
    public final boolean IsFacility() {
      return (type == 1);
    }
    /** @brief Mengembalikan nilai char code yang adalah atribut cell
    */
    public final char GetCode(){
      return code;
    }
}