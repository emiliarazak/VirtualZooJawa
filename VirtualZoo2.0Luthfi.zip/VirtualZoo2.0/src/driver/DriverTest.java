/**
 * 
 */
package driver;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author luthfi_fadillah
 *
 */
public class DriverTest {

	/**
	 * Test method for {@link driver.Driver#Driver()}.
	 */
	@Test
	public void testDriver() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link driver.Driver#MainMenu()}.
	 */
	@Test
	public void testMainMenu() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link driver.Driver#DisplayVirtualZoo(int)}.
	 */
	@Test
	public void testDisplayVirtualZoo() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link driver.Driver#TourVirtualZoo()}.
	 */
	@Test
	public void testTourVirtualZoo() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link driver.Driver#DisplayMakanan()}.
	 */
	@Test
	public void testDisplayMakanan() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link driver.Driver#DisplayLegend()}.
	 */
	@Test
	public void testDisplayLegend() {
		fail("Not yet implemented");
	}

}
