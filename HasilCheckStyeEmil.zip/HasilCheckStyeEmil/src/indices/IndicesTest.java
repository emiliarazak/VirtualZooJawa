package indices;
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class IndicesTest {
	private Indices ind = new Indices (5,6);
	private Indices in = new Indices();
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}
	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}
	@Test
	public void testIndicesIntInt() {
		assertEquals("Constructor Indices parameter 1 Error!", 5, ind.getAbsis());
		assertEquals("Constructor Indices parameter 2 Error!", 6, ind.getOrdinat());
	}
	@Test
	public void testCopyIndices() {
		in.copyIndices(ind);
		assertEquals("Constructor Indices parameter 1 Error!", 5, in.getAbsis());
		assertEquals("Constructor Indices parameter 2 Error!", 6, in.getOrdinat());
	}
	@Test
	public void testGetAbsis() {
		assertEquals("getAbsis() Error!", 5, ind.getAbsis());
	}
	@Test
	public void testGetOrdinat() {
		assertEquals("getOrdinat() Error!", 6, ind.getOrdinat());
	}
	@Test
	public void testSetAbsis() {
		ind.setAbsis(3);
		assertEquals("SetAbsis() Error!", 3, ind.getAbsis());
		ind.setAbsis(5);
	}
	@Test
	public void testSetOrdinat() {
		ind.setOrdinat(4);
		assertEquals("SetOrdinat() Error!", 4, ind.getOrdinat());
		ind.setOrdinat(6);
	}
	@Test
	public void testIsEqual() {
		in.copyIndices(ind);
		assertEquals("IsEqual() Error!", true, ind.isEqual(in));
	}
	@Test
	public void testPrintKoordinat() {
		ind.printKoordinat();
		assertEquals("PrintKoordinat() Error!", "(" + 5 + ", " + 6 + ")\n", outContent.toString());
	}
}