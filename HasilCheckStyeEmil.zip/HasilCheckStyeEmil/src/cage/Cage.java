
package cage;

import animal.Animal;
import indices.Indices;

/** Kelas Cell tanpa inheritance.
 * 
 * @author alivia.
 *
 */

public class Cage {
  //atribut
  /**  Attribut wilayah adalah Array of Indices kandang yang termasuk pada kandang
   */
  Indices[] wilayah;
  /**  Attribut data_animal adalah Array of Animal yang tinggal dikandang tersebut
   */
  Animal[] dataAnimal;
  /**  Attribut luas menyatakan luasnya kandang.
   */
  int luas;
  /**  Attribut banyak_hewan menyatakan jumlah hewan yang hidup di kandang.
    */
  int banyakHewan;
  int kapasitas;
  //method
  /**  Constructor tanpa parameter dari Cage.
    * Menghidupkan kandang.
    */
    
  public Cage() { }
  /** Constructor dengan parameter dari Cage.
    * Menghidupkan kandang sesuai dengan input parameter.
    *
    * @param ind array of Indices menyatakan Cell dengan indices yang tergabung dalam cage.
    * @param neff integer menyatakan banyaknya Indices yang ada pada array.
    */
    
  public Cage(Indices[] ind, int neff) {
    int i;
    wilayah = new Indices[neff];
    for (i = 0; i < neff; i++) {
      wilayah[i] = new Indices();
      wilayah[i].copyIndices(ind[i]);
    }
    luas = neff;
    banyakHewan = 0;
    kapasitas = (neff * 3) / 10;
    dataAnimal = new Animal [kapasitas];
    for (i = 0; i < ((neff * 3) / 10); i++) {
      dataAnimal[i] = new Animal();
    }
  }
  /** Mengembalikan nilai booleanean apakah indices termasuk pada cangkupan cage.
    *
    * @param ind adalah indices yang diperiksa sebagai bagian dari cage.
    */
    
  public boolean isHostOf(Indices ind) {
    boolean ketemu = false;
    int i = 0;
    while ((i < luas) && (!(ketemu))) {
      ketemu = (ind.isEqual(wilayah[i]));
      i++;
    }    
    return ketemu;
  }
  /**Mengembalikan nilai booleanean apakah masih ada ruang untuk animal di cage tersebut.
    */
    
  public boolean spacious() {
    return (banyakHewan < kapasitas);
  }
  /**Prosedur addAnimal dari Cage.
    *I.S Cage telah hidup dan Masukkan terdefinisi sebagai hewan yang hidup.
    *F.S Animal A tercatat pada Data Animals Cage.
    *Menambahkan Animals A pada Data Animals Cage.
    *
    *@param a adalah Pointer to Animal yang ingin dimasukkan di Data Animals.
    */
    
  public void addAnimal(Animal a) {
    Indices ind;
    ind = new Indices(a.getKoordinat().getAbsis(), a.getKoordinat().getOrdinat());
    if (isHostOf(ind)) {
      if (spacious()) {
        if (!(a.isJinak())) {
          if (banyakHewan == 0) {
            dataAnimal[banyakHewan].copyAnimal(a); 
            banyakHewan++;
          } else {
            if (a.getBerat() == dataAnimal[0].getBerat()) {
              dataAnimal[banyakHewan].copyAnimal(a);
              banyakHewan++;
            }
          }
        } else {
          dataAnimal[banyakHewan].copyAnimal(a);
          banyakHewan++;
        }
      }
    }
  }
  /**Prosedur Inter dari Cage.
    *I.S Cage terdefinisi.
    *F.S Memanggil semua prosedur interact dari animals yang ada di Cage.
    *Mencetak semua suara binatang yang ada dalam kandang.
    */

  public void inter() {
    for (int i = 0; i < banyakHewan; i++) {
      dataAnimal[i].interact();
    }
  }
  /**Mengembalikan nilai atribut dataAnimal.
    *
    */
    
  public Animal[] getAnimals() {
    return dataAnimal;
  }
  /**GetLuas dari cage.
    *Mengembalikan nilai luas suatu kandang.
    *
    */
    
  public int getLuas() {
    return luas;
  }
  /**GetBanyakHewan dari Cage.
    * Mengembalikan nilai banyaknya hewan yang ada di suatu kandang.
    */
    
  public int getBanyakHewan() {
    return banyakHewan;
  }
  /**Mengembalikan nilai atribut wilayah.
    */
    
  public Indices[] getWilayah() {
    return wilayah;
  }
  /** Prosedur CopyCage.
    * I.S Cage C terdefinisi.
    * F.S Menyalin Cage C ke current objek.
    * 
    * @param c cage yang ingin dicopy ke current objek.
    */
    
  public void copyCage(Cage c) {
    luas = c.luas;
    banyakHewan = c.banyakHewan;
    wilayah = new Indices[luas];
    int i;
    for (i = 0; i < luas; i++) {
      wilayah[i] = new Indices();
      wilayah[i].copyIndices(c.getWilayah()[i]);
    }   
    dataAnimal = new Animal[banyakHewan];
    for (i = 0; i < banyakHewan; i++) {
      dataAnimal[i].copyAnimal(c.getAnimals()[i]);
    }
  }
}  