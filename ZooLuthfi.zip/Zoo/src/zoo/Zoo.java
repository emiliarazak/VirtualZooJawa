/**
 * 
 */
package zoo;

/**
 * @author luthfi_fadillah
 *
 */
class Zoo {

}
