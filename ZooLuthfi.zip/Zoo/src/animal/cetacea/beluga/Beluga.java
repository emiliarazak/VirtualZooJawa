/**
 * 
 */

package animal.cetacea.beluga;

import animal.cetacea.Cetacea;
import renderable.Renderable;

/**Real Class Beluga.
 * @author Luthfi Fadillah
 *
 */

public class Beluga extends Cetacea implements Renderable {
  /** Constructor dari Beluga.
   * Menghidupkan hewan Beluga.
   *
   * @param x : bertipe int, adalah letak absis Beluga yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Beluga yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Beluga yang dihidupkan.
   */
  
  public Beluga(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
  }
  
  @Override
  /** Prosedur Interact dari objek Beluga.
   * I.S : hewan telah dihidupkan.
   * F.S : interaksi hewan tercetak ke layar.
   * Mencetak interaksi Beluga ke layar.
   */
  
  public void Interact() {
    System.out.println("Ooooooooooooo...");
  }
  
  /** Mengembalikan nilai character kode dari objek Beluga.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  
  public char render() {
    return 'B';
  }
}
