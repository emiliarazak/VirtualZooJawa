/**
 * 
 */

package animal.cetacea.orca;

import animal.cetacea.Cetacea;
import renderable.Renderable;

/**Real Class Orca.
 * @author Luthfi Fadillah
 *
 */

public class Orca extends Cetacea implements Renderable {
  /** Constructor dari Orca.
   * Menghidupkan hewan Orca.
   *
   * @param x : bertipe int, adalah letak absis Orca yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Orca yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Orca yang dihidupkan.
   */
  
  public Orca(int bb, int x, int y) {
    super(false, x, y);
    SetBerat(bb);
  }
  
  @Override
  /** Prosedur Interact dari objek Orca.
   * I.S : hewan telah dihidupkan.
   * F.S : interaksi hewan tercetak ke layar.
   * Mencetak interaksi Orca ke layar.
   */
  
  public void Interact() {
    System.out.println("*WWUSHHHO");
  }
  
  /** Mengembalikan nilai character kode dari objek Orca.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  
  public char render() {
    return '$';
  }
}
