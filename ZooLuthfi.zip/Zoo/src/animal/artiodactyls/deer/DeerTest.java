/**
 * 
 */
package animal.artiodactyls.deer;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.*;


/**
 * @author luthfi_fadillah
 *
 */
public class DeerTest {
	private Deer x = new Deer(30,1,2);
	
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

	@Before
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	}

	@After
	public void cleanUpStreams() {
	    System.setOut(null);
	}
	
	/**
	 * Test method for {@link animal.artiodactyls.Deer.Deer#Interact()}.
	 */
	@Test
	public void testInteract() {
		x.Interact();
	    assertEquals("Interact() Error!","Do you know where is santa house??\n", outContent.toString());
	}

	/**
	 * Test method for {@link animal.artiodactyls.Deer.Deer#Deer(int, int, int)}.
	 */
	@Test
	public void testDeer() {
	    assertEquals("Constructor Deer parameter 1 Error!", 30, x.GetBerat());
	    assertEquals("Constructor Deer parameter 2 Error!", 1, x.GetKoordinat().GetAbsis());
	    assertEquals("Constructor Deer parameter 3 Error!", 2, x.GetKoordinat().GetOrdinat());
	}

	/**
	 * Test method for {@link animal.artiodactyls.Deer.Deer#render()}.
	 */
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'D', x.render());
	}

	/**
	 * Test method for {@link animal.artiodactyls.Artiodactyls#Artiodactyls(boolean, int, int)}.
	 */
	@Test
	public void testArtiodactyls() {
		assertEquals("Constructor Artiodactyls parameter 1 Error!", true, x.IsJinak());
	    assertEquals("Constructor Artiodactyls parameter 2 Error!", 1, x.GetKoordinat().GetAbsis());
	    assertEquals("Constructor Artiodactyls parameter 3 Error!", 2, x.GetKoordinat().GetOrdinat());
	}

	/**
	 * Test method for {@link animal.Animal#Animal(int, boolean, boolean, boolean, boolean, int, int)}.
	 */
	@Test
	public void testAnimalConstructorWithParameter() {
		assertEquals("Constructor Animal parameter 1 Error!", 0, x.GetMakanan());
	    assertEquals("Constructor Animal parameter 2 Error!", true, x.IsLandAnimal());
	    assertEquals("Constructor Animal parameter 3 Error!", false, x.IsWaterAnimal());
		assertEquals("Constructor Animal parameter 4 Error!", false, x.IsAirAnimal());
		assertEquals("Constructor Animal parameter 5 Error!", true, x.IsJinak());
	    assertEquals("Constructor Animal parameter 6 Error!", 1, x.GetKoordinat().GetAbsis());
	    assertEquals("Constructor Animal parameter 7 Error!", 2, x.GetKoordinat().GetOrdinat());
	}

	/**
	 * Test method for {@link animal.Animal#GetBerat()}.
	 */
	@Test
	public void testGetBerat() {
	    assertEquals("GetBerat() Error!", 30, x.GetBerat());
	}

	/**
	 * Test method for {@link animal.Animal#SetBerat(int)}.
	 */
	@Test
	public void testSetBerat() {
		x.SetBerat(50);
	    assertEquals("SetBerat() Error!", 50, x.GetBerat());
		x.SetBerat(30);
	}

	/**
	 * Test method for {@link animal.Animal#GetKoordinat()}.
	 */
	@Test
	public void testGetKoordinat() {
	    assertEquals("GetKoordinat Absis Error!", 1, x.GetKoordinat().GetAbsis());
	    assertEquals("GetKoordinat Ordinat Error!", 2, x.GetKoordinat().GetOrdinat());		
	}

	/**
	 * Test method for {@link animal.Animal#SetKoordinat(int, int)}.
	 */
	@Test
	public void testSetKoordinat() {
		x.SetKoordinat(3, 4);
	    assertEquals("SetKoordinat Absis Error!", 3, x.GetKoordinat().GetAbsis());
	    assertEquals("SetKoordinat Ordinat Error!", 4, x.GetKoordinat().GetOrdinat());
	    x.SetKoordinat(1, 2);
	}

	/**
	 * Test method for {@link animal.Animal#IsLandAnimal()}.
	 */
	@Test
	public void testIsLandAnimal() {
	    assertEquals("IsLandAnimal() Error!", true, x.IsLandAnimal());
	}

	/**
	 * Test method for {@link animal.Animal#IsWaterAnimal()}.
	 */
	@Test
	public void testIsWaterAnimal() {
	    assertEquals("IsWaterAnimal() Error!", false, x.IsWaterAnimal());
	}

	/**
	 * Test method for {@link animal.Animal#IsAirAnimal()}.
	 */
	@Test
	public void testIsAirAnimal() {
		assertEquals("IsAirAnimal() Error!", false, x.IsAirAnimal());
	}

	/**
	 * Test method for {@link animal.Animal#IsJinak()}.
	 */
	@Test
	public void testIsJinak() {
		assertEquals("IsJinak() Error!", true, x.IsJinak());
	}

	/**
	 * Test method for {@link animal.Animal#GetMakanan()}.
	 */
	@Test
	public void testGetMakanan() {
		assertEquals("GetMakanan() Error!", 0, x.GetMakanan());
	}

	/**
	 * Test method for {@link animal.Animal#CopyAnimal(animal.Animal)}.
	 */
	@Test
	public void testCopyAnimal() {
		Deer y = new Deer(40,2,3);
		y.CopyAnimal(x);
		assertEquals("CopyAnimal() Error!", 0, y.GetMakanan());
	    assertEquals("CopyAnimal() Error!", true, y.IsLandAnimal());
	    assertEquals("CopyAnimal() Error!", false, y.IsWaterAnimal());
		assertEquals("CopyAnimal() Error!", false, y.IsAirAnimal());
		assertEquals("CopyAnimal() Error!", true, y.IsJinak());
	    assertEquals("CopyAnimal() Error!", 1, y.GetKoordinat().GetAbsis());
	    assertEquals("CopyAnimal() Error!", 2, y.GetKoordinat().GetOrdinat());
	    assertEquals("CopyAnimal() Error!", 30, y.GetBerat());
	}

}
