/**
 * 
 */

package animal.artiodactyls.giraffe;

import animal.artiodactyls.Artiodactyls;
import renderable.Renderable;

/**Real Class Giraffe.
 * @author Luthfi Fadillah
 *
 */
public class Giraffe extends Artiodactyls implements Renderable {
  /** Constructor dari Giraffe.
   * Menghidupkan hewan Giraffe.
   *
   * @param x integer adalah letak absis Giraffe yang dihidupkan
   * @param y integer adalah letak ordinat Giraffe yang dihidupkan
   * @param bb integer adalah berat badan Giraffe yang dihidupkan
   */

  public Giraffe(int bb, int x, int y) {
    super(true,x,y);
    SetBerat(bb);
  }

  @Override
  /** prosedur Interact dari objek Giraffe.
   * I.S : hewan telah dihidupkan.
   * F.S : interaksi hewan tercetak ke layar.
   * Mencetak interaksi Giraffe ke layar.
   */
  
  public void Interact() {
    System.out.println("where are u? i cant see you! are you down there?? please come up!");
  }

  /** Mengembalikan nilai character kode dari objek Giraffe.
   * @return char : kode yang nantinya siap dicetak ke layar
   */
  
  public char render() {
    return 'G';
  }
}
