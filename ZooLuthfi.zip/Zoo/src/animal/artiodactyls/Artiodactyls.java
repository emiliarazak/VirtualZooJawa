/**
 * 
 */

package animal.artiodactyls;

import animal.Animal;

/**Abstract Class Artiodactyls.
 * @author Luthfi Fadillah
 *
 */
public abstract class Artiodactyls extends Animal {
  /** Constructor dari Artiodactyls.
   * Menghidupkan hewan Ordo Artiodactyls.
   *
   * @param x : bertipe int, adalah letak absis Artiodactyls yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Artiodactyls yang dihidupkan.
   * @param kejinakan : bertipe bool, menyatakan jinak tidaknya hewan.
   */

  public Artiodactyls(boolean kejinakan, int x, int y) {
    super(0,true,false,false,kejinakan,x,y);
  }
}
