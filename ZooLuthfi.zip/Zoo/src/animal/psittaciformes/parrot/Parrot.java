/**
 * 
 */

package animal.psittaciformes.parrot;

import animal.psittaciformes.Psittaciformes;
import renderable.Renderable;

/**Real Class Parrot.
 * @author Luthfi Fadillah
 *
 */

public class Parrot extends Psittaciformes implements Renderable {
  /** Constructor dari Parrot.
   * Menghidupkan hewan Parrot.
   *
   * @param x : bertipe int, adalah letak absis Parrot yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Parrot yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Parrot yang dihidupkan.
   */
  
  public Parrot(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
  }
  
  @Override
  /** Prosedur Interact dari objek Parrot.
   * I.S : hewan telah dihidupkan.
   * F.S : interaksi hewan tercetak ke layar.
   * Mencetak interaksi Parrot ke layar.
   */
  
  public void Interact() {
    System.out.println("Anyeong..");
  }
  
  /** Mengembalikan nilai character kode dari objek Parrot.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  
  public char render() {
    return 'X';
  }
}
