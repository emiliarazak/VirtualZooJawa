/**
 * 
 */

package animal.psittaciformes;

import animal.Animal;

/**Abstract Class Psittaciformes.
 * @author Luthfi Fadillah
 *
 */
public abstract class Psittaciformes extends Animal {
  /** Constructor dari Psittaciformes.
   * Menghidupkan hewan Ordo Psittaciformes.
   *
   * @param x : bertipe int, adalah letak absis Psittaciformes yang dihidupkan. 
   * @param y : bertipe int, adalah letak ordinat Psittaciformes yang dihidupkan.
   * @param kejinakan : bertipe bool, menyatakan jinak tidaknya hewan.
   */
  
  public Psittaciformes(boolean kejinakan, int x, int y) {
    super(1,false,false,true,kejinakan,x,y);
  }
}