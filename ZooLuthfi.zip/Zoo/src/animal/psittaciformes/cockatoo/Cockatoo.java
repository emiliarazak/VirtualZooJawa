/**
 * 
 */

package animal.psittaciformes.cockatoo;

import animal.psittaciformes.Psittaciformes;
import renderable.Renderable;

/**Real Class Cockatoo.
 * @author Luthfi Fadillah
 *
 */
public class Cockatoo extends Psittaciformes implements Renderable {
  /** Constructor dari Cockatoo.
   * Menghidupkan hewan Cockatoo.
   *
   * @param x : bertipe int, adalah letak absis Cockatoo yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Cockatoo yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Cockatoo yang dihidupkan.
   */
  
  public Cockatoo(int bb, int x, int y) {
    super(true,x,y);
    SetBerat(bb);
  }

  @Override
  /** Prosedur Interact dari objek Cockatoo.
   * I.S : hewan telah dihidupkan.
   * F.S : interaksi hewan tercetak ke layar.
   * Mencetak interaksi Cockatoo ke layar.
   */
  
  public void Interact() {
    System.out.println("Cockatooo... Cockatooo...");
  }

  /** Mengembalikan nilai character kode dari objek Cockatoo.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  
  public char render() {
    return '0';
  }
}
